/*
  Check42 - Bad,expensive key lookup in a clustered columnstore
*/

