/* 
  Check 2 - Index fragmentation
*/

SELECT 'Check 2 - Index fragmentation' AS [Info],
        a.Database_Name,
        a.Schema_Name,
        a.Table_Name,
        a.Index_Name,
        a.Index_Type,
        a.Indexed_Columns,
        a.Number_Rows,
        a.data_compression_desc,
        a.ReservedSizeInMB,
        a.Buffer_Pool_SpaceUsed_MB,
        a.Buffer_Pool_FreeSpace_MB,
        CONVERT(NUMERIC(18, 2), (a.Buffer_Pool_FreeSpace_MB / CASE WHEN a.Buffer_Pool_SpaceUsed_MB = 0 THEN 1 ELSE a.Buffer_Pool_SpaceUsed_MB END) * 100) AS Buffer_Pool_FreeSpace_Percent,
        a.fill_factor,
        CONVERT(NUMERIC(18, 2), a.avg_fragmentation_in_percent) AS avg_fragmentation_in_percent,
        CONVERT(NUMERIC(18, 2), a.avg_page_space_used_in_percent) AS avg_page_space_used_in_percent,
        forwarded_record_count, -- for heaps
        CASE 
          WHEN CONVERT(NUMERIC(18, 2), a.avg_fragmentation_in_percent) > 5 THEN 'Warning - This index is fragmented. It is recommended to remove fragmentation on a regular basis to maintain performance'
          ELSE 'OK'
        END AS [Comment 1]
 FROM tempdb.dbo.Tab_GetIndexInfo a
 ORDER BY avg_fragmentation_in_percent DESC,
          ReservedSizeInMB DESC;