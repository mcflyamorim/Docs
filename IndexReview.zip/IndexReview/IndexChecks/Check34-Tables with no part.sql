/* 
  Check 34 - Tables with more than 10mi rows and no partitioning
*/

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
SELECT TOP 1000
       'Check 34 - Tables with more than 10mi rows and no partitioning' AS [Info],
       a.Database_Name,
       a.Schema_Name,
       a.Table_Name,
       a.Index_Name,
       a.Index_Type,
       a.Indexed_Columns,
       a.Number_Rows,
       a.ReservedSizeInMB AS [Table Size]
  FROM tempdb.dbo.Tab_GetIndexInfo a
 WHERE a.Number_Rows >= 10000000
   AND a.IsTablePartitioned = 0
ORDER BY a.ReservedSizeInMB DESC, 
         a.Database_Name,
         a.Schema_Name,
         a.Table_Name,
         a.Index_Name
