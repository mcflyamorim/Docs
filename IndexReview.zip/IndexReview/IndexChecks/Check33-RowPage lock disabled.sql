/* 
  Check 33 - Indexes with row or page lock disabled
*/

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
SELECT TOP 1000
       'Check 33 - Indexes with row or page lock disabled' AS [Info],
       a.Database_Name,
       a.Schema_Name,
       a.Table_Name,
       a.Index_Name,
       a.Index_Type,
       a.Indexed_Columns,
       a.Number_Rows,
       a.ReservedSizeInMB AS [Table Size],
       a.allow_row_locks,
       a.allow_page_locks
  FROM tempdb.dbo.Tab_GetIndexInfo a
 WHERE (a.allow_row_locks = 0 OR a.allow_page_locks = 0)
   AND a.Index_Type NOT IN ('CLUSTERED COLUMNSTORE', 'NONCLUSTERED COLUMNSTORE')
ORDER BY a.ReservedSizeInMB DESC, 
         a.Database_Name,
         a.Schema_Name,
         a.Table_Name,
         a.Index_Name
