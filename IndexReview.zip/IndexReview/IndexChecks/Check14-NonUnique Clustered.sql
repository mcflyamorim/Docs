/* 
  Check 14 - Non-unique clustered indexes
*/

SELECT 'Check 14 - Non-unique clustered indexes' AS [Info],
        a.Database_Name,
        a.Schema_Name,
        a.Table_Name,
        a.Index_Name,
        a.Index_Type,
        a.Indexed_Columns,
        a.Number_Rows,
        a.ReservedSizeInMB,
        a.[is_unique],
        CASE
            WHEN [is_unique] = 0 AND index_ID = 1 THEN
                '[WARNING: Clustered index is non-unique. Revise the need to have non-unique clustering keys to which a uniquefier is added]'
            ELSE
                'OK'
        END AS [Comment]
   FROM tempdb.dbo.Tab_GetIndexInfo AS a
  WHERE [is_unique] = 0 AND index_ID = 1
  ORDER BY a.Number_Rows DESC, 
            a.Database_Name,
            a.Schema_Name,
            a.Table_Name,
            a.ReservedSizeInMB DESC,
            a.Index_Name