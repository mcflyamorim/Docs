/* 
  Check 37 - Top 1000 indexes with more row or page locks
*/

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
SELECT TOP 1000
       'Check 37 - Top 1000 indexes with more row or page locks' AS [Info],
       a.Database_Name,
       a.Schema_Name,
       a.Table_Name,
       a.Index_Name,
       a.Index_Type,
       a.Indexed_Columns,
       a.Number_Rows,
       a.ReservedSizeInMB AS [Table Size],
       a.row_lock_wait_count,
       a.row_lock_wait_in_ms,
       a.page_lock_count,
       a.page_lock_wait_in_ms
  FROM tempdb.dbo.Tab_GetIndexInfo a
 WHERE a.row_lock_wait_count + a.page_lock_count > 0
ORDER BY a.row_lock_wait_count + a.page_lock_count DESC,
         a.ReservedSizeInMB DESC, 
         a.Database_Name,
         a.Schema_Name,
         a.Table_Name,
         a.Index_Name
