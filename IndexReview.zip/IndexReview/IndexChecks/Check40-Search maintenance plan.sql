/*
  Check 40 - Search for an index maintenance plan
*/

-- Fabiano Amorim
-- http:\\www.blogfabiano.com | fabianonevesamorim@hotmail.com
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

DECLARE @dbid int, @dbname VARCHAR(1000), @sqlcmd NVARCHAR(4000)
DECLARE @ErrorMessage NVARCHAR(4000)

IF EXISTS (SELECT [object_id] FROM tempdb.sys.objects (NOLOCK) WHERE [object_id] = OBJECT_ID('tempdb.dbo.##tmp1'))
DROP TABLE ##tmp1;
IF NOT EXISTS (SELECT [object_id] FROM tempdb.sys.objects (NOLOCK) WHERE [object_id] = OBJECT_ID('tempdb.dbo.##tmp1'))
CREATE TABLE ##tmp1 ([DBName] VARCHAR(800), [Schema] VARCHAR(800), [Object] VARCHAR(800), [Type] VARCHAR(100), [JobName] VARCHAR(800), [Step] VARCHAR(800), CommandFound VARCHAR(8000));
		
IF EXISTS (SELECT [object_id] FROM tempdb.sys.objects (NOLOCK) WHERE [object_id] = OBJECT_ID('tempdb.dbo.#tblKeywords'))
DROP TABLE #tblKeywords;
IF NOT EXISTS (SELECT [object_id] FROM tempdb.sys.objects (NOLOCK) WHERE [object_id] = OBJECT_ID('tempdb.dbo.#tblKeywords'))
CREATE TABLE #tblKeywords (
	KeywordID int IDENTITY(1,1) PRIMARY KEY,
	Keyword VARCHAR(64) -- the keyword itself
	);

IF NOT EXISTS (SELECT [object_id] FROM tempdb.sys.indexes (NOLOCK) WHERE name = N'UI_Keywords' AND [object_id] = OBJECT_ID('tempdb.dbo.#tblKeywords'))
CREATE UNIQUE INDEX UI_Keywords ON #tblKeywords(Keyword);

INSERT INTO #tblKeywords (Keyword)
VALUES ('ALTER INDEX'), ('DBCC DBREINDEX'), ('REORGANIZE'), ('SHOWCONTIG'), ('INDEXDEFRAG')

IF EXISTS
(
   SELECT [object_id]
   FROM tempdb.sys.objects (NOLOCK)
   WHERE [object_id] = OBJECT_ID('tempdb.dbo.#tmpdbs0')
)
   DROP TABLE #tmpdbs0;
IF NOT EXISTS
(
   SELECT [object_id]
   FROM tempdb.sys.objects (NOLOCK)
   WHERE [object_id] = OBJECT_ID('tempdb.dbo.#tmpdbs0')
)
   CREATE TABLE #tmpdbs0
   (
       id INT IDENTITY(1, 1),
       [dbid] INT,
       [dbname] NVARCHAR(1000),
       is_read_only BIT,
       [state] TINYINT,
       isdone BIT
   );

SET @sqlcmd
   = N'SELECT database_id, name, is_read_only, [state], 0 FROM master.sys.databases (NOLOCK) 
               WHERE state_desc = ''ONLINE'' and is_read_only = 0';
INSERT INTO #tmpdbs0
(
   [dbid],
   [dbname],
   is_read_only,
   [state],
   [isdone]
)
EXEC sp_executesql @sqlcmd;

UPDATE #tmpdbs0
SET isdone = 0;

IF (SELECT COUNT(id) FROM #tmpdbs0 WHERE isdone = 0) > 0
BEGIN
	 WHILE (SELECT COUNT(id) FROM #tmpdbs0 WHERE isdone = 0) > 0
	 BEGIN
		  SELECT TOP 1 @dbname = [dbname], @dbid = [dbid] FROM #tmpdbs0 WHERE isdone = 0

		  SET @sqlcmd = 'USE ' + QUOTENAME(@dbname) + ';
                   SELECT N''' + REPLACE(@dbname, CHAR(39), CHAR(95)) + ''' AS [DBName], ss.name AS [Schema_Name], so.name AS [Object_Name], so.type_desc, tk.Keyword
                   FROM sys.sql_modules sm (NOLOCK)
                   INNER JOIN sys.objects so (NOLOCK) ON sm.[object_id] = so.[object_id]
                   INNER JOIN sys.schemas ss (NOLOCK) ON so.[schema_id] = ss.[schema_id]
                   CROSS JOIN #tblKeywords tk (NOLOCK)
                   WHERE PATINDEX(''%'' + tk.Keyword + ''%'', LOWER(sm.[definition]) COLLATE DATABASE_DEFAULT) > 1
                   AND OBJECTPROPERTY(sm.[object_id],''IsMSShipped'') = 0;'

    BEGIN TRY
	     INSERT INTO ##tmp1 ([DBName], [Schema], [Object], [Type], CommandFound)
	     EXECUTE sp_executesql @sqlcmd
    END TRY
    BEGIN CATCH
	     SELECT ERROR_NUMBER() AS ErrorNumber, ERROR_MESSAGE() AS ErrorMessage;
	     SELECT @ErrorMessage = 'Error raised in TRY block. ' + ERROR_MESSAGE()
	     RAISERROR (@ErrorMessage, 16, 1);
    END CATCH
		
		  UPDATE #tmpdbs0
		  SET isdone = 1
		  WHERE [dbid] = @dbid
	 END
END;

INSERT INTO #tblKeywords (Keyword)
SELECT DISTINCT Object
FROM ##tmp1

SET @sqlcmd = 'USE [msdb];
               SELECT t.[DBName], t.[Schema], t.[Object], t.[Type], sj.[name], sjs.step_name, sjs.[command]
               FROM msdb.dbo.sysjobsteps sjs (NOLOCK)
               INNER JOIN msdb.dbo.sysjobs sj (NOLOCK) ON sjs.job_id = sj.job_id
               CROSS JOIN #tblKeywords tk (NOLOCK)
               OUTER APPLY (SELECT TOP 1 * FROM ##tmp1 WHERE ##tmp1.[Object] = tk.Keyword) AS t
               WHERE PATINDEX(''%'' + tk.Keyword + ''%'', LOWER(sjs.[command]) COLLATE DATABASE_DEFAULT) > 0
               AND sjs.[subsystem] IN (''TSQL'',''PowerShell'', ''CMDEXEC'');'

BEGIN TRY
	 INSERT INTO ##tmp1 ([DBName], [Schema], [Object], [Type], JobName, Step, CommandFound)
	 EXECUTE sp_executesql @sqlcmd
END TRY
BEGIN CATCH
	 SELECT ERROR_NUMBER() AS ErrorNumber, ERROR_MESSAGE() AS ErrorMessage;
	 SELECT @ErrorMessage = 'Error raised in jobs TRY block. ' + ERROR_MESSAGE()
	 RAISERROR (@ErrorMessage, 16, 1);
END CATCH

IF (SELECT COUNT(*) FROM ##tmp1) > 0
BEGIN
		SELECT 'Check 40 - Search for an index maintenance plan' AS [Info],
         DBName,
         [Schema],
         Object,
         Type,
         JobName,
         Step,
         CommandFound 
  FROM ##tmp1
  WHERE JobName IS NOT NULL
END
ELSE
BEGIN
	 SELECT 'Check 40 - Search for an index maintenance plan' AS [Info],
         'Could not find a job or procedure running index defrag, check manually.'
END;
