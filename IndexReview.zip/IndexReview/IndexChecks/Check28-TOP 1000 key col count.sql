/* 
  Check 28 - Top 1000 indexes with largest index key
*/

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
SELECT TOP 1000
       'Check 28 - Top 1000 indexes with largest index key' AS [Info],
       a.Database_Name,
       a.Schema_Name,
       a.Table_Name,
       a.Index_Name,
       a.Index_Type,
       a.Indexed_Columns,
       a.Number_Rows,
       a.data_compression_desc,
       a.ReservedSizeInMB,
       a.Buffer_Pool_SpaceUsed_MB,
       LEN(CONVERT(VARCHAR(MAX), indexed_columns)) - LEN(REPLACE(CONVERT(VARCHAR(MAX), indexed_columns), ',', '')) + 1 AS KeyColumnsCount
  FROM tempdb.dbo.Tab_GetIndexInfo a
ORDER BY LEN(CONVERT(VARCHAR(MAX), indexed_columns)) - LEN(REPLACE(CONVERT(VARCHAR(MAX), indexed_columns), ',', '')) + 1 DESC,
         a.Number_Rows DESC, 
         a.Database_Name,
         a.Schema_Name,
         a.Table_Name,
         a.ReservedSizeInMB DESC,
         a.Index_Name
