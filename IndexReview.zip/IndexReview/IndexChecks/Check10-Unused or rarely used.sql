/* 
  Check 10 - Unused or rarely used indexes
*/

SELECT 'Check 10 - Unused or rarely used indexes' AS [Info],
        a.Database_Name,
        a.Schema_Name,
        a.Table_Name,
        a.Index_Name,
        a.Index_Type,
        a.Indexed_Columns,
        a.Number_Rows,
        a.ReservedSizeInMB,
        Tab1.[Reads_Ratio],
	       Tab2.[Writes_Ratio],
        ISNULL(Number_of_Reads,0) AS [Number of reads], 
        ISNULL([Total Writes],0) AS [Number of writes], 
        CASE 
          WHEN Number_of_Reads = 0 AND [Total Writes] > 0 THEN '[WARNING: Unused index with update. It is recommended to revise the need to maintain all these objects as soon as possible]'
          ELSE  'OK'
        END AS [Comment 1],
        CASE 
          WHEN Number_of_Reads = 0 AND [Total Writes] = 0 THEN '[WARNING: Unused index without update. It is recommended to revise the need to maintain all these objects as soon as possible]'
          ELSE  'OK'
        END AS [Comment 2],
        CASE 
          WHEN Number_of_Reads > 0 AND [Reads_Ratio] < 5 THEN '[WARNING: Rarely used index. It is recommended to revise the need to maintain all these objects as soon as possible]'
          ELSE  'OK'
        END AS [Comment 3]
   FROM tempdb.dbo.Tab_GetIndexInfo AS a
   CROSS APPLY (SELECT ISNULL(CONVERT(NUMERIC(18, 2),CAST(CASE WHEN (a.user_seeks + a.user_scans + a.user_lookups) = 0 THEN 0 ELSE CONVERT(REAL, (a.user_seeks + a.user_scans + a.user_lookups)) * 100 /
              		       CASE (a.user_seeks + a.user_scans + a.user_lookups + a.user_updates) WHEN 0 THEN 1 ELSE CONVERT(REAL, (a.user_seeks + a.user_scans + a.user_lookups + a.user_updates)) END END AS DECIMAL(18,2))),0)) AS Tab1([Reads_Ratio])
   CROSS APPLY (SELECT ISNULL(CONVERT(NUMERIC(18, 2),CAST(CASE WHEN a.user_updates = 0 THEN 0 ELSE CONVERT(REAL, a.user_updates) * 100 /
		                     CASE (a.user_seeks + a.user_scans + a.user_lookups + a.user_updates) WHEN 0 THEN 1 ELSE CONVERT(REAL, (a.user_seeks + a.user_scans + a.user_lookups + a.user_updates)) END END AS DECIMAL(18,2))),0)) AS Tab2([Writes_Ratio])
  ORDER BY a.Number_Rows DESC, 
           a.Database_Name,
           a.Schema_Name,
           a.Table_Name,
           a.ReservedSizeInMB DESC,
           a.Index_Name