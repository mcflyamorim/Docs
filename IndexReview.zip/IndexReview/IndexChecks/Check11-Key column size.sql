/* 
  Check 11 - Key column size
*/

DECLARE @sqlmajorver int
SELECT @sqlmajorver = CONVERT(int, (@@microsoftversion / 0x1000000) & 0xff);

SELECT 'Check 11 - Key column size' AS [Info],
        a.Database_Name,
        a.Schema_Name,
        a.Table_Name,
        a.Index_Name,
        a.Index_Type,
        a.Indexed_Columns,
        a.Number_Rows,
        a.ReservedSizeInMB,
        a.[KeyCols_data_length_bytes],
        CASE
            WHEN @sqlmajorver < 13 THEN
                '[WARNING: Index key is larger than 900 bytes. It is recommended to revise these]'
            ELSE
                '[WARNING: Index key is larger than allowed (900 bytes for clustered index; 1700 bytes for nonclustered index). It is recommended to revise these]'
        END AS [Comment]
   FROM tempdb.dbo.Tab_GetIndexInfo AS a
  WHERE (
              [KeyCols_data_length_bytes] > 900
              AND @sqlmajorver < 13
          )
          OR
          (
              [KeyCols_data_length_bytes] > 900
              AND Index_Type IN ( 'CLUSTERED', 'CLUSTERED COLUMNSTORE' )
              AND @sqlmajorver >= 13
          )
          OR
          (
              [KeyCols_data_length_bytes] > 1700
              AND Index_Type IN ( 'NONCLUSTERED', 'NONCLUSTERED COLUMNSTORE' )
              AND @sqlmajorver >= 13
          )
ORDER BY a.Number_Rows DESC, 
           a.Database_Name,
           a.Schema_Name,
           a.Table_Name,
           a.ReservedSizeInMB DESC,
           a.Index_Name