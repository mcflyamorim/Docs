/* 
  Check 38 - Return all heaps with more than 1k rows

  Should this table really be a heap?
*/

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
SELECT 'Check 38 - Return all heaps' AS [Info],
       a.Database_Name,
       a.Schema_Name,
       a.Table_Name,
       a.Index_Name,
       a.Index_Type,
       a.Indexed_Columns,
       a.Number_Rows,
       a.ReservedSizeInMB AS [Table Size]       
  FROM tempdb.dbo.Tab_GetIndexInfo a
 WHERE a.Index_Type = 'HEAP'
   AND a.Number_Rows >= 1000
ORDER BY a.Number_Rows DESC, 
         a.Database_Name,
         a.Schema_Name,
         a.Table_Name,
         a.Index_Name
