/* 
  Check 24 - Top 1000 indexes waiting for PAGEIOLATCH
*/

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
SELECT TOP 1000
       'Check 24 - Top 1000 indexes waiting for PAGEIOLATCH' AS [Info],
       a.Database_Name,
       a.Schema_Name,
       a.Table_Name,
       a.Index_Name,
       a.Index_Type,
       a.Indexed_Columns,
       a.Number_Rows,
       a.ReservedSizeInMB,
       a.page_io_latch_wait_count,
       a.page_io_latch_wait_in_ms,
       CAST(1. * a.page_io_latch_wait_in_ms / NULLIF(a.page_io_latch_wait_count ,0) AS decimal(12,2)) AS page_io_avg_lock_wait_ms
  FROM tempdb.dbo.Tab_GetIndexInfo a
 WHERE a.page_io_latch_wait_count > 0
   AND a.Table_Name NOT LIKE N'plan_%'
   AND a.Table_Name NOT LIKE N'sys%'
   AND a.Table_Name NOT LIKE N'xml_index_nodes%'
ORDER BY A.page_io_latch_wait_count DESC,
         a.Number_Rows DESC, 
         a.Database_Name,
         a.Schema_Name,
         a.Table_Name,
         a.ReservedSizeInMB DESC,
         a.Index_Name
