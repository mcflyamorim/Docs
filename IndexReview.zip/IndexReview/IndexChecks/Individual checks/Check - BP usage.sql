/* 
USE [Change to DB you want to check] 
*/

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SET ARITHABORT OFF 
SET ANSI_WARNINGS OFF
SET LOCK_TIMEOUT 1000; /* 1 second */

DECLARE @sqlmajorver INT, @sql NVARCHAR(MAX), @msg NVARCHAR(MAX)
SELECT @sqlmajorver = CONVERT(INT, (@@microsoftversion / 0x1000000) & 0xff);

/* This may take a while depending on how much RAM is available for SQL */
SET @sql = 
'
IF OBJECT_ID(''tempdb.dbo.##tmp_buffer_descriptors'') IS NOT NULL
    DROP TABLE ##tmp_buffer_descriptors;

SELECT database_id
       ,file_id
       ,page_id
       ,allocation_unit_id
       ,free_space_in_bytes
       ,numa_node '
       + CASE WHEN @sqlmajorver >= 11 /*SQL2012*/ THEN ', read_microsec' ELSE '' END + '
INTO ##tmp_buffer_descriptors
FROM sys.dm_os_buffer_descriptors
WHERE dm_os_buffer_descriptors.page_type IN (''DATA_PAGE'', ''INDEX_PAGE'')
AND dm_os_buffer_descriptors.database_id = DB_ID(); ' +
CASE 
  WHEN @sqlmajorver >= 11 /*SQL2012*/ THEN 'CREATE CLUSTERED INDEX ix1 ON ##tmp_buffer_descriptors (database_id, allocation_unit_id, read_microsec);' 
  ELSE 'CREATE CLUSTERED INDEX ix1 ON ##tmp_buffer_descriptors (database_id, allocation_unit_id, page_id);' 
END +
CASE 
  WHEN @sqlmajorver < 11 /*SQL2012*/ THEN 'ALTER TABLE ##tmp_buffer_descriptors ADD read_microsec BIGINT NULL;' 
  ELSE '' 
END

BEGIN TRY
  EXEC sp_executesql @sql
END TRY
BEGIN CATCH
  SET @msg = 'Error trying get info from sys.dm_os_buffer_descriptors'
  RAISERROR(@msg, 10, 1) WITH NOWAIT

  SET @msg = ERROR_MESSAGE()
  RAISERROR(@msg, 16, 1)
  RETURN
END CATCH

/*
  Capturing info about existing indexes in a cursor to avoid get blocked while 
  trying to acquire a LCK_M_SCH_S on DMVs
  If info about an specific table is not available, I'll skipt it and move forward 
  to collect data for next object.
*/

IF OBJECT_ID('tempdb.dbo.#tmp_index') IS NOT NULL
  DROP TABLE #tmp_index;

SELECT DB_ID() AS [database_id],
       DB_NAME() AS [database_name],
       sc.name AS 'schema_name',
       t.name AS 'table_name',
       i.name AS 'index_name',
       au.allocation_unit_id,
       t.object_id,
       i.index_id,
       i.type_desc AS 'index_type',
       i.fill_factor,
       p.rows AS 'number_rows',
       p.data_compression_desc,
       t_size.reserved_size_mb,
       t_size.reserved_page_count,
       t_size.used_page_count
INTO #tmp_index
FROM sys.indexes i
INNER JOIN sys.tables t
ON t.object_id = i.object_id
INNER JOIN sys.schemas sc
ON sc.schema_id = t.schema_id
INNER JOIN sys.partitions AS p
ON i.object_id = p.object_id
AND i.index_id = p.index_id
INNER JOIN sys.allocation_units AS au
ON au.container_id = p.hobt_id
AND au.type_desc = 'IN_ROW_DATA'
CROSS APPLY (SELECT CONVERT(DECIMAL(18, 2), SUM((st.reserved_page_count * 8) / 1024.)) reserved_size_mb,
                    SUM(st.reserved_page_count) AS reserved_page_count,
                    SUM(st.used_page_count) AS used_page_count
             FROM sys.dm_db_partition_stats st
             WHERE i.object_id = st.object_id
             AND i.index_id = st.index_id
             AND p.partition_number = st.partition_number
             AND st.partition_number = 1) AS t_size
WHERE OBJECTPROPERTY(i.object_id, 'IsUserTable') = 1
AND i.type NOT IN (5, 6) /*ignoring columnstore indexes*/
AND p.partition_number = 1
AND p.rows >= 1 /*ignoring empty tables*/

CREATE UNIQUE CLUSTERED INDEX ix1 ON #tmp_index(database_id, allocation_unit_id)


/*
  Check objects with high latency I/Os
*/

IF @sqlmajorver >= 11 /*SQL2012*/
BEGIN
  IF OBJECT_ID('tempdb.dbo.#tmp_high_latency_reads') IS NOT NULL
    DROP TABLE #tmp_high_latency_reads;

  SELECT i.database_name, 
         i.schema_name,
         i.table_name,
         i.index_name,
         t1.top_1_longest_read_ms,
         STUFF(t2.top_10_longest_reads_ms, 1, 3, '') AS top_10_longest_reads_ms
  INTO #tmp_high_latency_reads
  FROM #tmp_index AS i
  CROSS APPLY (SELECT TOP 1 
                      CONVERT(NUMERIC(18, 2),(read_microsec / 1000.))
               FROM ##tmp_buffer_descriptors AS bd
               WHERE bd.database_id = i.database_id
               AND bd.allocation_unit_id = i.allocation_unit_id
               ORDER BY read_microsec DESC) AS t1(top_1_longest_read_ms)
  CROSS APPLY (SELECT TOP 10 
                      ' - ' + CONVERT(VARCHAR, CONVERT(NUMERIC(18, 2), (read_microsec / 1000.))) AS "text()"
               FROM ##tmp_buffer_descriptors AS bd
               WHERE bd.database_id = i.database_id
               AND bd.allocation_unit_id = i.allocation_unit_id
               ORDER BY read_microsec DESC
               FOR XML PATH('')) AS t2(top_10_longest_reads_ms)
  WHERE top_1_longest_read_ms > 100 /* all reads that took more than 100ms */
         
  IF EXISTS(SELECT * FROM #tmp_high_latency_reads)
  BEGIN
    SELECT 'Warning - Found events of high latency I/Os based on time it took to run the I/O used to read and save the page on buffer pool data cache. It is recommemded to review the I/O subsystem to avoid those high latency reads.' AS [Comment]
    SELECT * FROM #tmp_high_latency_reads
    ORDER BY top_1_longest_read_ms DESC, 
             database_name, 
             schema_name,
             table_name,
             index_name
  END
  ELSE
  BEGIN
    SELECT 'OK - No high latency I/O events were found, looks like it is all good.' AS [Comment]
  END
END

/*
  Check BP distribution per index
*/
IF OBJECT_ID('tempdb.dbo.#tmp_bp_distribution_per_index') IS NOT NULL
  DROP TABLE #tmp_bp_distribution_per_index;

SELECT i.database_id,
       i.database_name,
       i.schema_name,
       i.table_name,
       i.index_name,
       i.index_type,
       i.data_compression_desc,
       i.number_rows,
       CONVERT(BIGINT, CONVERT(NUMERIC(18,8), i.number_rows) / CONVERT(NUMERIC(18,8), i.used_page_count)) AS avg_rows_per_page,
       CONVERT(DECIMAL(18, 2), 8192 / (CONVERT(NUMERIC(18,8), i.number_rows) / CONVERT(NUMERIC(18,8), i.used_page_count))) AS avg_row_size_kb,
       i.reserved_size_mb,
       i.reserved_page_count,
       i.used_page_count,
       bd.buffer_pool_spaceused_mb,
       bd.buffer_pool_freespace_mb,
       bd.buffer_pool_freespace_percent,
       bd.current_page_percent_usage,
       i.fill_factor AS index_fill_factor,
       i.allocation_unit_id,
       i.object_id,
       i.index_id
INTO #tmp_bp_distribution_per_index
FROM #tmp_index AS i
OUTER APPLY (SELECT CONVERT(DECIMAL(18, 2), (COUNT(*) * 8) / 1024.) AS buffer_pool_spaceused_mb,
                    CONVERT(DECIMAL(18, 2), (SUM(CONVERT(FLOAT, free_space_in_bytes)) / 1024.) / 1024.) AS buffer_pool_freespace_mb,
                    CONVERT(SMALLINT, ROUND((AVG(CONVERT(FLOAT, free_space_in_bytes)) / 8192.) * 100, 0)) AS buffer_pool_freespace_percent,
                    CONVERT(SMALLINT, ROUND(((8192 - AVG(CONVERT(FLOAT, free_space_in_bytes))) / 8192.) * 100, 0)) AS current_page_percent_usage
             FROM ##tmp_buffer_descriptors AS bd
             WHERE bd.database_id = i.database_id
             AND bd.allocation_unit_id = i.allocation_unit_id) AS bd

IF EXISTS(SELECT CONVERT(DECIMAL(18, 2),SUM(buffer_pool_spaceused_mb / 1024)) AS total_buffer_pool_spaceused_gb,
                 CONVERT(DECIMAL(18, 2),SUM(buffer_pool_freespace_mb / 1024)) AS total_buffer_pool_freespace_gb,
                 CONVERT(DECIMAL(18, 2),(SUM(buffer_pool_freespace_mb) / SUM(buffer_pool_spaceused_mb)) * 100) AS total_buffer_pool_freespace_percent
          FROM #tmp_bp_distribution_per_index
          HAVING CONVERT(DECIMAL(18, 2),(SUM(buffer_pool_freespace_mb) / SUM(buffer_pool_spaceused_mb)) * 100) >= 10)
BEGIN
  SELECT 'Warning - At least 10% of data on buffer pool data cache is empty. It is recommended to review the index fragmentation and fillfactor to avoid this waste of mem usage.' AS [Comment]
  SELECT CONVERT(DECIMAL(18, 2),SUM(buffer_pool_spaceused_mb / 1024)) AS total_buffer_pool_spaceused_gb,
         CONVERT(DECIMAL(18, 2),SUM(buffer_pool_freespace_mb / 1024)) AS total_buffer_pool_freespace_gb,
         CONVERT(DECIMAL(18, 2),(SUM(buffer_pool_freespace_mb) / SUM(buffer_pool_spaceused_mb)) * 100) AS total_buffer_pool_freespace_percent
  FROM #tmp_bp_distribution_per_index
END
ELSE
BEGIN
  SELECT 'OK - Looks like free space on BP data cache is ok, but, you may still want to review the following resultset to confirm.' AS [Comment]
  SELECT CONVERT(DECIMAL(18, 2),SUM(buffer_pool_spaceused_mb / 1024)) AS total_buffer_pool_spaceused_gb,
         CONVERT(DECIMAL(18, 2),SUM(buffer_pool_freespace_mb / 1024)) AS total_buffer_pool_freespace_gb,
         CONVERT(DECIMAL(18, 2),(SUM(buffer_pool_freespace_mb) / SUM(buffer_pool_spaceused_mb)) * 100) AS total_buffer_pool_freespace_percent
  FROM #tmp_bp_distribution_per_index
END

SELECT * FROM #tmp_bp_distribution_per_index
ORDER BY buffer_pool_spaceused_mb DESC,
         number_rows, 
         database_name,
         schema_name,
         table_name,
         reserved_size_mb,
         index_name