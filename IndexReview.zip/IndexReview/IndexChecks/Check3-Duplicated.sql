/* 
  Check 3 - Duplicated indexes

  There is clearly no benefit from having the same index more than once, but on the other hand there is quite a 
  lot of overhead that each index incurs. 
  The overhead includes the storage consumed by the index, the on-going maintenance during DML statements, 
  the periodical rebuild and/or reorganize operations, and the additional complexity that the optimizer
  has to deal with when evaluating possible access methods to the relevant table or view.


*/

SELECT 'Check 3 - Duplicated indexes' AS [Info],
       a.Database_Name,
       a.Schema_Name,
       a.Table_Name,
       a.Index_Name,
       a.Index_Type,
       a.Indexed_Columns,
       a.included_columns,
       a.filter_definition,
       a.Number_Rows,
       a.ReservedSizeInMB,
       a.Duplicated_Index_Identified,
       DropCmd = 
       N'USE ' + QUOTENAME(a.Database_Name) + ';' + NCHAR(13) + NCHAR(10) 
       + 'EXEC sp_helpindex2 ' + '''' + QUOTENAME(a.Schema_Name) + N'.' + QUOTENAME(a.Table_Name) + ''''
       + '/* NumberOfRows = ' + CONVERT(VARCHAR, Number_Rows) + '*/'
       + NCHAR(13) + NCHAR(10) +
       + N'-- DROP INDEX ' + QUOTENAME(a.Index_Name) + N' ON ' + QUOTENAME(a.Schema_Name) + N'.' + QUOTENAME(a.Table_Name) + N';'
       + NCHAR(13) + NCHAR(10) +
       'GO',
       DisableCmd = 
       N'USE ' + QUOTENAME(a.Database_Name) + ';' + NCHAR(13) + NCHAR(10) 
       + 'ALTER INDEX ' + QUOTENAME(a.Index_Name) + N' ON ' + QUOTENAME(a.Schema_Name) + N'.' + QUOTENAME(a.Table_Name) + ' DISABLE;' 
       + NCHAR(13) + NCHAR(10) +
       'GO'
  FROM tempdb.dbo.Tab_GetIndexInfo a
 --WHERE a.Duplicated_Index_Identified
ORDER BY a.Number_Rows DESC, 
         a.Database_Name,
         a.Schema_Name,
         a.Table_Name,
         CONVERT(VARCHAR(MAX), a.Indexed_Columns),
         a.ReservedSizeInMB DESC,
         a.Index_Name
