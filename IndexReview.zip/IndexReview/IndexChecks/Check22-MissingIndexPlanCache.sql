/* 
  Check 22 - TOP 1000 Missing indexes from plan cache
*/

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
;with xmlnamespaces 
(
  default 'http://schemas.microsoft.com/sqlserver/2004/07/showplan'
)
select TOP 1000
       'Check 22 - TOP 1000 Missing indexes from plan CACHE' AS [Info],
       Impact
      ,TableName=IxDB+'.'+IxSchema+'.'+IxTable
      ,KeyCols
      ,IncludeCols
      ,IndexCommand
      ,usecounts
      ,size_in_bytes
      ,objtype
      ,BatchCode
      --,QueryPlan=qp.query_plan 
from sys.dm_exec_cached_plans qs 
cross apply 
  --Get the Query Text
  sys.dm_exec_sql_text(qs.plan_handle) qt             
cross apply 
  --Get the Query Plan
  sys.dm_exec_query_plan(qs.plan_handle) qp
cross apply
  --Get the Code for the Batch in Hyperlink Form
  (select BatchCode
            =(select [processing-instruction(q)]=':'+nchar(13)+qt.text+nchar(13)
              for xml path(''),type)
  ) F_Code
cross apply
  --Find the Missing Indexes Group Nodes in the Plan
  qp.query_plan.nodes('//MissingIndexes/MissingIndexGroup') F_GrpNodes(GrpNode)
cross apply 
  --Pull out the Impact Figure
  (select Impact=GrpNode.value('(./@Impact)','float')) F_Impact
cross apply 
  --Get the Missing Index Nodes from the Group
  GrpNode.nodes('(./MissingIndex)') F_IxNodes(IxNode)
cross apply 
  --Pull out the Database,Schema,Table of the Missing Index
  (select IxDB=IxNode.value('(./@Database)','sysname')
         ,IxSchema=IxNode.value('(./@Schema)','sysname')
         ,IxTable=IxNode.value('(./@Table)','sysname')
  ) F_IxInfo
cross apply 
  --How many INCLUDE columns are there;
  --And how many EQUALITY/INEQUALITY columns are there?
  (select NumIncludes
            =IxNode.value('count(./ColumnGroup[@Usage="INCLUDE"]/Column)','int')
         ,NumKeys
            =IxNode.value('count(./ColumnGroup[@Usage!="INCLUDE"]/Column)','int')
  ) F_NumIncl
cross apply 
  --Pull out the Key Columns and the Include Columns from the various Column Groups
  (select EqCols=max(case when Usage='EQUALITY' then ColList end)
         ,InEqCols=max(case when Usage='INEQUALITY' then ColList end)
         ,IncludeCols=max(case when Usage='INCLUDE' then ColList end)
   from IxNode.nodes('(./ColumnGroup)') F_ColGrp(ColGrpNode)
   cross apply 
     --Pull out the Usage of the Group? (EQUALITY of INEQUALITY or INCLUDE)
     (select Usage=ColGrpNode.value('(./@Usage)','varchar(20)')) F_Usage
   cross apply 
     --Get a comma-delimited list of the Column Names in the Group
     (select ColList=stuff((select ','+ColNode.value('(./@Name)','sysname')
                            from ColGrpNode.nodes('(./Column)') F_ColNodes(ColNode)
                            for xml path(''))
                          ,1,1,'')
     ) F_ColList
  ) F_ColGrps
cross apply
  --Put together the Equality and InEquality Columns
  (select KeyCols=isnull(EqCols,'')
                 +case 
                    when EqCols is not null and InEqCols is not null 
                    then ',' 
                    else '' 
                  end
                 +isnull(InEqCols,'')
  ) F_KeyCols
cross apply 
  --Construct a CREATE INDEX command
  (select IndexCommand='create index <InsertNameHere> on '
                      +IxDB+'.'+IxSchema+'.'+IxTable+' ('
                      +KeyCols+')'
                      +isnull(' include ('+IncludeCols+')','')) F_Cmd
where qs.cacheobjtype='Compiled Plan'
  --and usecounts>=5    --Only interested in those plans used at least 5 times
  --and NumKeys<=5      --Limit to the #columns we're willing to have in the index
  --and NumIncludes<=5  --Limit to the #columns we're willing to have in the INCLUDE list
  --and Impact>=50      --Only indexes that will have a 50% impact
order by Impact desc