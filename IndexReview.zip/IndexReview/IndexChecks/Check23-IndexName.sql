/* 
  Check 23 - Indexes with "test" or "missing index" on name
*/

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
SELECT 'Check 23 - Indexes with "test" or "missing index" on name' AS [Info],
       a.Database_Name,
       a.Schema_Name,
       a.Table_Name,
       a.Index_Name,
       a.Index_Type,
       a.Indexed_Columns,
       a.Number_Rows,
       a.ReservedSizeInMB
  FROM tempdb.dbo.Tab_GetIndexInfo a
 WHERE a.Index_Name COLLATE Latin1_General_BIN2 LIKE '%Missing Index%'
    OR a.Index_Name COLLATE Latin1_General_BIN2 LIKE '%MissingIndex%'
    OR a.Index_Name COLLATE Latin1_General_BIN2 LIKE '%Test%'
    OR a.Index_Name COLLATE Latin1_General_BIN2 LIKE '%Backup%'
    OR a.Index_Name COLLATE Latin1_General_BIN2 LIKE '%_DTA_%'
ORDER BY a.Number_Rows DESC, 
         a.Database_Name,
         a.Schema_Name,
         a.Table_Name,
         a.ReservedSizeInMB DESC,
         a.Index_Name
