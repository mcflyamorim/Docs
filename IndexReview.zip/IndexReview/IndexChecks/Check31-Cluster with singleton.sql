/* 
  Check 31 - Top 1000 clustered indexes with only singleton lookups or very few range scans

  If only of most of reads are singleton lookups, it maybe a good idea to re-create this index as a nonclustered and use cluster 
  in a column that requires range scans.
*/

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
SELECT TOP 1000
       'Check 31 - Top 1000 clustered indexes with only singleton lookups or very few range scans' AS [Info],
       a.Database_Name,
       a.Schema_Name,
       a.Table_Name,
       a.Index_Name,
       a.Index_Type,
       a.Indexed_Columns,
       a.Number_Rows,
       a.ReservedSizeInMB,
       a.singleton_lookup_count,
       a.range_scan_count,
       a.user_seeks,
       a.user_scans,
       a.user_lookups
  FROM tempdb.dbo.Tab_GetIndexInfo a
ORDER BY a.Number_of_Reads DESC,
         a.Number_Rows DESC, 
         a.Database_Name,
         a.Schema_Name,
         a.Table_Name,
         a.ReservedSizeInMB DESC,
         a.Index_Name
