/* 
  Check 16 - Foreign Keys with no Index
*/

SET NOCOUNT ON;

DECLARE @sqlcmd NVARCHAR(MAX),
        @params NVARCHAR(600),
        @sqlmajorver INT;
DECLARE @dbid INT,
        @dbname NVARCHAR(1000);
DECLARE @ErrorSeverity INT,
        @ErrorState INT,
        @ErrorMessage NVARCHAR(4000);

IF EXISTS
(
    SELECT [object_id]
    FROM tempdb.sys.objects (NOLOCK)
    WHERE [object_id] = OBJECT_ID('tempdb.dbo.#tmpdbs0')
)
    DROP TABLE #tmpdbs0;
IF NOT EXISTS
(
    SELECT [object_id]
    FROM tempdb.sys.objects (NOLOCK)
    WHERE [object_id] = OBJECT_ID('tempdb.dbo.#tmpdbs0')
)
    CREATE TABLE #tmpdbs0
    (
        id INT IDENTITY(1, 1),
        [dbid] INT,
        [dbname] NVARCHAR(1000),
        is_read_only BIT,
        [state] TINYINT,
        isdone BIT
    );

SET @sqlcmd
    = N'SELECT database_id, name, is_read_only, [state], 0 FROM master.sys.databases (NOLOCK) 
                WHERE name in (select Database_name FROM tempdb.dbo.Tab_GetIndexInfo)';
INSERT INTO #tmpdbs0
(
    [dbid],
    [dbname],
    is_read_only,
    [state],
    [isdone]
)
EXEC sp_executesql @sqlcmd;

IF EXISTS
(
    SELECT [object_id]
    FROM tempdb.sys.objects (NOLOCK)
    WHERE [object_id] = OBJECT_ID('tempdb.dbo.#tblFK')
)
    DROP TABLE #tblFK;
IF NOT EXISTS
(
    SELECT [object_id]
    FROM tempdb.sys.objects (NOLOCK)
    WHERE [object_id] = OBJECT_ID('tempdb.dbo.#tblFK')
)
    CREATE TABLE #tblFK
    (
        [databaseID] INT,
        [DatabaseName] sysname,
        [constraint_name] NVARCHAR(200),
        [parent_schema_name] NVARCHAR(100),
        [parent_table_name] NVARCHAR(200),
        parent_columns NVARCHAR(4000),
        [referenced_schema] NVARCHAR(100),
        [referenced_table_name] NVARCHAR(200),
        referenced_columns NVARCHAR(4000),
        CONSTRAINT PK_FK
            PRIMARY KEY CLUSTERED (
                                      databaseID,
                                      [constraint_name],
                                      [parent_schema_name]
                                  )
    );

UPDATE #tmpdbs0
SET isdone = 0;

UPDATE #tmpdbs0
SET isdone = 1
WHERE [state] <> 0
      OR [dbid] = 2;

WHILE
(SELECT COUNT(id)FROM #tmpdbs0 WHERE isdone = 0) > 0
BEGIN
    SELECT TOP 1
           @dbname = [dbname],
           @dbid = [dbid]
    FROM #tmpdbs0
    WHERE isdone = 0;
    SET @sqlcmd
        = N'SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
           USE ' + QUOTENAME(@dbname)
          + N'
           ;WITH cteFK AS (
           SELECT t.name AS [parent_schema_name],
	           OBJECT_NAME(FKC.parent_object_id) [parent_table_name],
	           OBJECT_NAME(constraint_object_id) AS [constraint_name],
	           t2.name AS [referenced_schema],
	           OBJECT_NAME(referenced_object_id) AS [referenced_table_name],
	           SUBSTRING((SELECT '','' + RTRIM(COL_NAME(k.parent_object_id,parent_column_id)) AS [data()]
		           FROM sys.foreign_key_columns k (NOLOCK)
		           INNER JOIN sys.foreign_keys (NOLOCK) ON k.constraint_object_id = [object_id]
			           AND k.constraint_object_id = FKC.constraint_object_id
		           ORDER BY constraint_column_id
		           FOR XML PATH('''')), 2, 8000) AS [parent_columns],
	           SUBSTRING((SELECT '','' + RTRIM(COL_NAME(k.referenced_object_id,referenced_column_id)) AS [data()]
		           FROM sys.foreign_key_columns k (NOLOCK)
		           INNER JOIN sys.foreign_keys (NOLOCK) ON k.constraint_object_id = [object_id]
			           AND k.constraint_object_id = FKC.constraint_object_id
		           ORDER BY constraint_column_id
		           FOR XML PATH('''')), 2, 8000) AS [referenced_columns]
           FROM sys.foreign_key_columns FKC (NOLOCK)
           INNER JOIN sys.objects o (NOLOCK) ON FKC.parent_object_id = o.[object_id]
           INNER JOIN sys.tables mst (NOLOCK) ON mst.[object_id] = o.[object_id]
           INNER JOIN sys.schemas t (NOLOCK) ON t.[schema_id] = mst.[schema_id]
           INNER JOIN sys.objects so (NOLOCK) ON FKC.referenced_object_id = so.[object_id]
           INNER JOIN sys.tables AS mst2 (NOLOCK) ON mst2.[object_id] = so.[object_id]
           INNER JOIN sys.schemas AS t2 (NOLOCK) ON t2.[schema_id] = mst2.[schema_id]
           WHERE o.type = ''U'' AND so.type = ''U''
           GROUP BY o.[schema_id],so.[schema_id],FKC.parent_object_id,constraint_object_id,referenced_object_id,t.name,t2.name
           ),
           cteIndexCols AS (
           SELECT t.name AS schemaName,
           OBJECT_NAME(mst.[object_id]) AS objectName,
           SUBSTRING(( SELECT '','' + RTRIM(ac.name) FROM sys.tables AS st
	           INNER JOIN sys.indexes AS mi ON st.[object_id] = mi.[object_id]
	           INNER JOIN sys.index_columns AS ic ON mi.[object_id] = ic.[object_id] AND mi.[index_id] = ic.[index_id] 
	           INNER JOIN sys.all_columns AS ac ON st.[object_id] = ac.[object_id] AND ic.[column_id] = ac.[column_id]
	           WHERE i.[object_id] = mi.[object_id] AND i.index_id = mi.index_id AND ic.is_included_column = 0
	           ORDER BY ac.column_id
           FOR XML PATH('''')), 2, 8000) AS KeyCols
           FROM sys.indexes AS i
           INNER JOIN sys.tables AS mst ON mst.[object_id] = i.[object_id]
           INNER JOIN sys.schemas AS t ON t.[schema_id] = mst.[schema_id]
           WHERE i.[type] IN (1,2,5,6) AND i.is_unique_constraint = 0
	           AND mst.is_ms_shipped = 0
           )
           SELECT ' + CONVERT(VARCHAR(8), @dbid) + N' AS Database_ID, ''' + REPLACE(@dbname, CHAR(39), CHAR(95))
          + N''' AS Database_Name, fk.constraint_name AS constraintName,
	           fk.parent_schema_name AS schemaName, fk.parent_table_name AS tableName,
	           REPLACE(fk.parent_columns,'' ,'','','') AS parentColumns, fk.referenced_schema AS referencedSchemaName,
	           fk.referenced_table_name AS referencedTableName, REPLACE(fk.referenced_columns,'' ,'','','') AS referencedColumns
           FROM cteFK fk
           WHERE NOT EXISTS (SELECT 1 FROM cteIndexCols ict 
					           WHERE fk.parent_schema_name = ict.schemaName
						           AND fk.parent_table_name = ict.objectName 
						           AND REPLACE(fk.parent_columns,'' ,'','','') = ict.KeyCols);';
    BEGIN TRY
        INSERT INTO #tblFK
        EXECUTE sp_executesql @sqlcmd;
    END TRY
    BEGIN CATCH
        SELECT ERROR_NUMBER() AS ErrorNumber,
               ERROR_MESSAGE() AS ErrorMessage;
        SELECT @ErrorMessage
            = N'Foreign Keys with no Index subsection - Error raised in TRY block in database ' + @dbname + N'. '
              + ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
    END CATCH;

    UPDATE #tmpdbs0
    SET isdone = 1
    WHERE [dbid] = @dbid;
END;

IF
(
    SELECT COUNT(*)FROM #tblFK
) > 0
BEGIN
    SELECT 'Check 15 - Clustered Indexes with GUIDs in key' AS [Info],
           FK.[DatabaseName] AS [Database_Name],
           constraint_name AS [Constraint_Name],
           FK.parent_schema_name AS [Schema_Name],
           FK.parent_table_name AS [Table_Name],
           FK.parent_columns AS parentColumns,
           FK.referenced_schema AS Referenced_Schema_Name,
           FK.referenced_table_name AS Referenced_Table_Name,
           FK.referenced_columns AS referencedColumns,
           '[WARNING: Some Foreign Key constraints are not supported by an Index. It is recommended to revise these]' AS [Comment],
           CreateIndexCmd = 'USE ' + [DatabaseName] + '; ' + 'CREATE INDEX IX_' + REPLACE(constraint_name, ' ', '_')
                            + ' ON ' + QUOTENAME(parent_schema_name) + '.' + QUOTENAME(parent_table_name) + ' (['
                            + REPLACE(REPLACE(parent_columns, ',', '],['), ']]', ']') + ']);'
    FROM #tblFK FK
    ORDER BY [DatabaseName],
             parent_schema_name,
             parent_table_name,
             referenced_schema,
             Referenced_Table_Name;
END;
ELSE
BEGIN
    SELECT 'Check 15 - Clustered Indexes with GUIDs in key' AS [Info],
           '[OK]' AS [Comment];
END;
