/* 
  Check 27 - Top 1000 index scans

  Good candidates for a columnstore and batch mode
*/

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
SELECT TOP 1000
       'Check 27 - Top 1000 index scans' AS [Info],
       a.Database_Name,
       a.Schema_Name,
       a.Table_Name,
       a.Index_Name,
       a.Index_Type,
       a.Indexed_Columns,
       a.Number_Rows,
       a.data_compression_desc,
       a.ReservedSizeInMB,
       a.Buffer_Pool_SpaceUsed_MB,
       a.user_scans,
       a.range_scan_count,
       a.page_io_latch_wait_count,
       a.page_io_latch_wait_in_ms
  FROM tempdb.dbo.Tab_GetIndexInfo a
WHERE a.user_scans > 0 OR a.range_scan_count > 0
ORDER BY a.user_scans DESC,
         a.Number_Rows DESC, 
         a.Database_Name,
         a.Schema_Name,
         a.Table_Name,
         a.ReservedSizeInMB DESC,
         a.Index_Name
