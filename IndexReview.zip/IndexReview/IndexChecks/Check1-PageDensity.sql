/* 
  Check 1 - Check indexes with small number of rows per page

  Usually, the bigger the number of rows in a page, the better.

  If table has LOB, make sure you're setting table to use "large value types out of row"
  Check if index ix compressed as it can help to increase number of rows in a page.
  A high fillfactor can help to avoid fragmentation, but will reduce number of rows in a page. 
*/

SELECT 'Check 1 - Check indexes with small number of rows per page' AS [Info],
       a.Database_Name,
       a.Schema_Name,
       a.Table_Name,
       a.Index_Name,
       a.Index_Type,
       a.Indexed_Columns,
       a.Number_Rows,
       a.data_compression_desc,
       a.ReservedSizeInMB,
       a.Buffer_Pool_SpaceUsed_MB,
       a.Buffer_Pool_FreeSpace_MB,
       CONVERT(NUMERIC(18, 2), (a.Buffer_Pool_FreeSpace_MB / CASE WHEN a.Buffer_Pool_SpaceUsed_MB = 0 THEN 1 ELSE a.Buffer_Pool_SpaceUsed_MB END) * 100) AS Buffer_Pool_FreeSpace_Percent,
       a.TableHasLOB,
       a.row_overflow_fetch_in_pages,
       a.row_overflow_fetch_in_bytes,
       a.large_value_types_out_of_row,
       a.fill_factor,
       CONVERT(NUMERIC(18, 2), a.avg_fragmentation_in_percent) AS avg_fragmentation_in_percent,
       CONVERT(NUMERIC(18, 2), a.avg_page_space_used_in_percent) AS avg_page_space_used_in_percent,
       a.avg_record_size_in_bytes,
       a.min_record_size_in_bytes,
       a.max_record_size_in_bytes,
       a.in_row_data_page_count,
       CONVERT(NUMERIC(18, 2), a.Number_Rows / a.in_row_data_page_count) AS [Avg rows per page],
       CONVERT(NUMERIC(18, 4), (a.Number_Rows / a.in_row_data_page_count) / 8192.) AS PageDensity
  FROM tempdb.dbo.Tab_GetIndexInfo a
 WHERE a.in_row_data_page_count > 0
ORDER BY a.Number_Rows DESC, 
         a.Database_Name,
         a.Schema_Name,
         a.Table_Name,
         a.ReservedSizeInMB DESC,
         a.Index_Name
