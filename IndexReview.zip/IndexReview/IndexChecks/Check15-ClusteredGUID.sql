/* 
  Check 15 - Clustered Indexes with GUIDs in key

  Remind to myself: Use operational stats to see if there are range or singleton reads and check if GUID is bad or really bad.

  https://techcommunity.microsoft.com/t5/sql-server/perfect-statistics-histogram-in-just-few-steps/ba-p/385734
  One note on GUIDs: my advice is just don�t use them as predicates, or on anything that requires good estimates for range scans. If you really, really have to use them as PK on a table to maintain uniqueness and therefore leverage singleton lookups as possible, then GUID is ok enough. But use NEWSEQUENTIALID generation instead of NEWID , create the PK as non-clustered, and get a surrogate key that can fulfill the requirements of a good clustering key .
*/

SELECT 'Check 15 - Clustered Indexes with GUIDs in key' AS [Info],
        a.Database_Name,
        a.Schema_Name,
        a.Table_Name,
        a.Index_Name,
        a.Index_Type,
        a.Indexed_Columns,
        a.Number_Rows,
        a.ReservedSizeInMB,
        a.[Key_has_GUID],
        CASE
            WHEN [is_unique] = 0 AND index_ID = 1 THEN
                '[WARNING: Clustered index with GUIDs in the key. It is recommended to revise these]'
            ELSE
                'OK'
        END AS [Comment]
   FROM tempdb.dbo.Tab_GetIndexInfo AS a
  WHERE [Key_has_GUID] > 0
  ORDER BY a.Number_Rows DESC, 
            a.Database_Name,
            a.Schema_Name,
            a.Table_Name,
            a.ReservedSizeInMB DESC,
            a.Index_Name