/* 
  Check 29 - Top 1000 tables with more indexes
*/

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
SELECT TOP 1000
       'Check 29 - Top 1000 tables with more indexes' AS [Info],
       a.Database_Name,
       a.Schema_Name,
       a.Table_Name,
       a.Index_Name,
       a.Index_Type,
       a.Indexed_Columns,
       a.Number_Rows,
       a.Number_Of_Indexes_On_Table
  FROM tempdb.dbo.Tab_GetIndexInfo a
ORDER BY a.Number_Of_Indexes_On_Table DESC,
         a.Number_Rows DESC, 
         a.Database_Name,
         a.Schema_Name,
         a.Table_Name,
         a.ReservedSizeInMB DESC,
         a.Index_Name
