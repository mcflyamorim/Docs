/*
  Check 41 - Heaps with NonClustered PKs with high number of seeks/singleton_lookups on heap

  If most of reads on PK are also doing a RID lookup, it may indicate this index (PK) would be
  better if it was recreated as a Clustered index. 
  If the PK is recreated as a Clustered, it would avoid all those RID lookups as it will
  have all columns.  
*/
USE master
GO
-- Fabiano Amorim
-- http:\\www.blogfabiano.com | fabianonevesamorim@hotmail.com
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

SELECT 'Check 41 - Heaps with NonClustered PKs with high number of seeks/singleton_lookups on heap' AS [Info],
       a.Database_Name,
       a.Schema_Name,
       a.Table_Name,
       a.Index_Name,
       a.Index_Type,
       a.Indexed_Columns,
       a.Number_Rows,
       a.ReservedSizeInMB,
       a.[user_seeks] AS pk_user_seeks,
       c.[user_seeks_all_other_nonclustered],
       b.[user_lookups] AS Heap_user_lookups,
       Tab1.Ratio_Of_NonClusteredSeeks_VS_HeapLookups,
       CASE 
         WHEN CONVERT(DECIMAL(18, 2), REPLACE(Tab1.Ratio_Of_NonClusteredSeeks_VS_HeapLookups, '%', '')) >= 80 
              THEN 'It looks like ' + Tab1.Ratio_Of_NonClusteredSeeks_VS_HeapLookups + 
                   ' of all reads on this NonClustered PKs did a RID lookup on heap, this may indicate PK is a good candidate to be recreated as a clustered index.'
         ELSE 'OK'
       END AS [Comment],
       CASE b.[singleton_lookup_count]
         WHEN 0 THEN '0%'
         ELSE CONVERT(VARCHAR, CAST((a.[singleton_lookup_count] / (ISNULL(b.[singleton_lookup_count], 1) * 1.00)) * 100.0 AS DECIMAL(18, 2)))  + '%' 
       END AS Ratio_Of_NonClusteredSingletonLookups_VS_HeapSingletonLookups,
       a.[range_scan_count], 
       b.[range_scan_count] AS Heap_range_scan_count, 
       a.[singleton_lookup_count],
       b.[singleton_lookup_count] AS Heap_singleton_lookup_count,
       b.[user_seeks] AS Heap_user_seeks,
       a.[user_scans],
       b.[user_scans] AS Heap_user_scans,
       a.[user_lookups],
       CmdToConvertIndexToClustered = N'USE ' + QUOTENAME(a.Database_Name) + N'; ' + 
       + NCHAR(13) + NCHAR(10) +
       '/* NumberOfRows = ' + CONVERT(VARCHAR, a.Number_Rows) + '*/' + 
       + NCHAR(13) + NCHAR(10) +
       'CREATE UNIQUE CLUSTERED INDEX ' + a.Index_Name + ' ON ' + 
       QUOTENAME(a.Schema_Name) + N'.' + QUOTENAME(a.Table_Name) + '(' + CONVERT(VARCHAR(MAX), a.Indexed_Columns) + ')' 
       + NCHAR(13) + NCHAR(10) +
       'WITH(DROP_EXISTING=ON)'
       + NCHAR(13) + NCHAR(10) +
       'GO'
FROM tempdb.dbo.Tab_GetIndexInfo a
INNER JOIN tempdb.dbo.Tab_GetIndexInfo b
ON a.Database_ID = b.Database_ID
AND a.Object_ID = b.Object_ID
AND b.Index_Type = 'HEAP'
CROSS APPLY (SELECT SUM(c.[user_seeks]) AS [user_seeks_all_other_nonclustered]
             FROM tempdb.dbo.Tab_GetIndexInfo c
             WHERE a.Database_ID = c.Database_ID
             AND a.Object_ID = c.Object_ID
             AND c.Index_Type = 'NONCLUSTERED'
             AND is_primary_key = 0) AS c
CROSS APPLY (SELECT CASE b.[user_lookups]
                      WHEN 0 THEN '0%'
                      ELSE CONVERT(VARCHAR, CAST(((a.[user_seeks] - c.[user_seeks_all_other_nonclustered]) / (ISNULL(b.[user_lookups], 1) * 1.00)) * 100.0 AS DECIMAL(18, 2)))  + '%' 
                    END AS Ratio_Of_NonClusteredSeeks_VS_HeapLookups) AS Tab1
WHERE a.is_primary_key = 1
AND a.Index_type = 'NONCLUSTERED'
AND a.Number_Rows >= 1000
ORDER BY a.Number_Rows DESC, 
          a.Database_Name,
          a.Schema_Name,
          a.Table_Name,
          a.ReservedSizeInMB DESC,
          a.Index_Name
