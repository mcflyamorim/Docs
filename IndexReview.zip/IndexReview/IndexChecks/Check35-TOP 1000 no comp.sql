/* 
  Check 35 - Top 1000 indexes without compression
*/

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
SELECT TOP 1000
       'Check 35 - Top 1000 indexes without compression' AS [Info],
       a.Database_Name,
       a.Schema_Name,
       a.Table_Name,
       a.Index_Name,
       a.Index_Type,
       a.Indexed_Columns,
       a.Number_Rows,
       a.ReservedSizeInMB AS [Table Size],
       a.Buffer_Pool_SpaceUsed_MB,
       a.Buffer_Pool_FreeSpace_MB,
       CONVERT(NUMERIC(18, 2), (a.Buffer_Pool_FreeSpace_MB / CASE WHEN a.Buffer_Pool_SpaceUsed_MB = 0 THEN 1 ELSE a.Buffer_Pool_SpaceUsed_MB END) * 100) AS Buffer_Pool_FreeSpace_Percent,
       a.TableHasLOB,
       a.data_compression_desc
  FROM tempdb.dbo.Tab_GetIndexInfo a
 WHERE a.data_compression_desc = 'NONE'
ORDER BY a.ReservedSizeInMB DESC, 
         a.Database_Name,
         a.Schema_Name,
         a.Table_Name,
         a.Index_Name
