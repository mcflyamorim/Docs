/* 
  Check 36 - Indexes with more than 1mi rows and stats set to ascending

  Those are good candidates for partitioning and purge data by the ascending col
*/

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SET NOCOUNT ON;

IF OBJECT_ID('tempdb.dbo.#TMP1') IS NOT NULL
  DROP TABLE #TMP1

SELECT TOP 1000
       'Check 36 - Indexes with more than 1mi rows and stats set to ascending' AS [Info],
       a.Database_Name,
       a.Schema_Name,
       a.Table_Name,
       a.Index_Name,
       a.Index_Type,
       a.Indexed_Columns,
       a.Number_Rows,
       a.ReservedSizeInMB AS [Table Size],
       a.Buffer_Pool_SpaceUsed_MB,
       a.Buffer_Pool_FreeSpace_MB,
       CONVERT(NUMERIC(18, 2), (a.Buffer_Pool_FreeSpace_MB / CASE WHEN a.Buffer_Pool_SpaceUsed_MB = 0 THEN 1 ELSE a.Buffer_Pool_SpaceUsed_MB END) * 100) AS Buffer_Pool_FreeSpace_Percent,
       a.TableHasLOB,
       UpdateStatsCmd = N'DBCC SHOW_STATISTICS (''' + QUOTENAME(a.Database_Name) + '.' + QUOTENAME(a.Schema_Name) + N'.' + QUOTENAME(a.Table_Name) + N''', '+ QUOTENAME(a.Index_Name) +') WITH NO_INFOMSGS;',
       CONVERT(VARCHAR(200),NULL) AS LeadingType
  INTO #TMP1
  FROM tempdb.dbo.Tab_GetIndexInfo a
 --WHERE a.Number_Rows >= 10000000
ORDER BY a.Number_Rows DESC, 
         a.Database_Name,
         a.Schema_Name,
         a.Table_Name,
         a.Index_Name


IF OBJECT_ID('tempdb.dbo.#TMPShowStatistics') IS NOT NULL
    DROP TABLE #TMPShowStatistics;

CREATE TABLE #TMPShowStatistics(
  [TF2388_Updated] datetime,
  [TF2388_Table Cardinality] BigInt,
  [TF2388_Snapshot Ctr] BigInt,
  [TF2388_Steps] BigInt,
  [TF2388_Density] Float,
  [TF2388_Rows Above] Float,
  [TF2388_Rows Below] Float,
  [TF2388_Squared Variance Error] Float,
  [TF2388_Inserts Since Last Update] Float,
  [TF2388_Deletes Since Last Update] Float,
  [TF2388_Leading column Type] NVarChar(200)
)

declare @UpdateStatsCmd VARCHAR(8000), @Msg VARCHAR(8000)

DBCC TRACEON(2388) WITH NO_INFOMSGS;

DECLARE c_StatsCmd CURSOR read_only FOR
    SELECT UpdateStatsCmd FROM #TMP1
OPEN c_StatsCmd

FETCH NEXT FROM c_StatsCmd
into @UpdateStatsCmd
WHILE @@FETCH_STATUS = 0
BEGIN
  /*SELECT @SQL*/
  BEGIN TRY
    INSERT INTO #TMPShowStatistics
    EXEC (@UpdateStatsCmd)

    UPDATE #TMP1 SET LeadingType = #TMPShowStatistics.[TF2388_Leading column Type]
    FROM #TMP1 t
    INNER JOIN #TMPShowStatistics
    ON t.UpdateStatsCmd = @UpdateStatsCmd
    WHERE #TMPShowStatistics.[TF2388_Leading column Type] IS NOT NULL  
  END TRY
		BEGIN CATCH
			 SELECT @Msg = 'Error trying to run ' + @UpdateStatsCmd
    RAISERROR (@Msg, 0,0) WITH NOWAIT
		END CATCH

  TRUNCATE TABLE #TMPShowStatistics
  FETCH NEXT FROM c_StatsCmd
  into @UpdateStatsCmd
END
CLOSE c_StatsCmd
DEALLOCATE c_StatsCmd

DBCC TRACEOFF(2388) WITH NO_INFOMSGS;

SELECT *
FROM #TMP1
WHERE LeadingType = 'Ascending'
ORDER BY Number_Rows DESC, 
         Database_Name,
         Schema_Name,
         Table_Name,
         Index_Name