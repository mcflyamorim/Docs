/* 
  Check 32 - Top 1000 tables with indexes total size greater than table size
*/

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
SELECT TOP 1000
       'Check 32 - Top 1000 tables with indexes total size greater than table size' AS [Info],
       a.Database_Name,
       a.Schema_Name,
       a.Table_Name,
       a.Index_Name,
       a.Index_Type,
       a.Indexed_Columns,
       a.Number_Rows,
       a.ReservedSizeInMB AS [Table Size],
       t.[Total Index Size],
       CASE 
         WHEN a.ReservedSizeInMB < [Total Index Size] THEN 'Warning - Total index size is greater than the table size.'
         ELSE 'OK'
       END AS [Comment]
  FROM tempdb.dbo.Tab_GetIndexInfo a
  OUTER APPLY (SELECT SUM(ReservedSizeInMB) FROM tempdb.dbo.Tab_GetIndexInfo b 
                WHERE a.Database_Name = b.Database_Name
                  AND a.object_id = b.object_id
                  AND b.Index_Type NOT IN ('HEAP', 'CLUSTERED', 'CLUSTERED COLUMNSTORE')) AS t ([Total Index Size])
 WHERE a.Index_Type IN ('HEAP', 'CLUSTERED', 'CLUSTERED COLUMNSTORE')
ORDER BY a.ReservedSizeInMB DESC, 
         a.Database_Name,
         a.Schema_Name,
         a.Table_Name,
         a.Index_Name
