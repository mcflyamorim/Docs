/* 
  Check 12 - Indexes with fill factor < 80 pct
*/

SELECT 'Check 12 - Indexes with fill factor < 80 pct' AS [Info],
        a.Database_Name,
        a.Schema_Name,
        a.Table_Name,
        a.Index_Name,
        a.Index_Type,
        a.Indexed_Columns,
        a.Number_Rows,
        a.ReservedSizeInMB,
        a.Fill_factor,
        CASE
            WHEN a.Fill_factor BETWEEN 1 AND 79 THEN
                '[WARNING: Index with fill factor lower than 80 percent. Revise the need to maintain such a low value]'
            ELSE
                'OK'
        END AS [Comment]
   FROM tempdb.dbo.Tab_GetIndexInfo AS a
  ORDER BY a.Number_Rows DESC, 
            a.Database_Name,
            a.Schema_Name,
            a.Table_Name,
            a.ReservedSizeInMB DESC,
            a.Index_Name