/* 
  Check 13 - Disabled indexes
*/

SELECT 'Check 13 - Disabled indexes' AS [Info],
        a.Database_Name,
        a.Schema_Name,
        a.Table_Name,
        a.Index_Name,
        a.Index_Type,
        a.Indexed_Columns,
        a.Number_Rows,
        a.ReservedSizeInMB,
        a.[is_disabled],
        CASE
            WHEN [is_disabled] = 1 THEN
                '[WARNING: Index is disabled. Revise the need to maintain these]'
            ELSE
                'OK'
        END AS [Comment]
   FROM tempdb.dbo.Tab_GetIndexInfo AS a
  WHERE [is_disabled] = 1
  ORDER BY a.Number_Rows DESC, 
            a.Database_Name,
            a.Schema_Name,
            a.Table_Name,
            a.ReservedSizeInMB DESC,
            a.Index_Name