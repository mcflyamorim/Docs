/* 
  Check 26 - Top 1000 lock escalations per index
*/

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
 
SELECT TOP 1000
       'Check 26 - Top 1000 lock escalations per index' AS [Info],
       a.Database_Name,
       a.Schema_Name,
       a.Table_Name,
       a.Index_Name,
       a.Index_Type,
       a.Indexed_Columns,
       a.Number_Rows,
       a.data_compression_desc,
       a.ReservedSizeInMB,
       a.allow_row_locks,
       a.allow_page_locks,
       a.lock_escalation_desc,
       a.index_lock_escaltion_count,
       a.index_lock_escaltion_attempt_count,
       a.row_lock_wait_count,
       a.row_lock_wait_in_ms,
       a.page_lock_count,
       a.page_lock_wait_in_ms
  FROM tempdb.dbo.Tab_GetIndexInfo a
WHERE a.index_lock_escaltion_count > 0
ORDER BY a.index_lock_escaltion_count DESC,
         a.Number_Rows DESC, 
         a.Database_Name,
         a.Schema_Name,
         a.Table_Name,
         a.ReservedSizeInMB DESC,
         a.Index_Name
