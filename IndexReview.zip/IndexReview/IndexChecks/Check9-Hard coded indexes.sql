/* 
  Check 9 - Hard coded indexes
*/

-- Fabiano Amorim
-- http:\\www.blogfabiano.com | fabianonevesamorim@hotmail.com
SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SET LOCK_TIMEOUT 1000; /*1 second*/

IF OBJECT_ID('tempdb.dbo.#db') IS NOT NULL
  DROP TABLE #db

IF OBJECT_ID('tempdb.dbo.#tmp_Obj2') IS NOT NULL
  DROP TABLE #tmp_Obj2

CREATE TABLE #tmp_Obj2 (DatabaseName                    NVarChar(800),
                        SchemaName                      NVarChar(800),
                        ObjectName                      NVarChar(800),
                        [Type of object]                NVarChar(800),
                        IndexName                       NVarChar(800),
                        [Object code definition]        XML)

SELECT d1.[name] into #db
FROM sys.databases d1
where d1.state_desc = 'ONLINE' and is_read_only = 0
and d1.database_id in (SELECT DISTINCT Database_ID FROM tempdb.dbo.Tab_GetIndexInfo)

DECLARE @SQL VarChar(MAX)
declare @database_name sysname
DECLARE @ErrMsg VarChar(8000)

DECLARE c_databases CURSOR read_only FOR
    SELECT [name] FROM #db
OPEN c_databases

FETCH NEXT FROM c_databases
into @database_name
WHILE @@FETCH_STATUS = 0
BEGIN
  SET @ErrMsg = 'Checking hard-coded indexes on DB - [' + @database_name + ']'
  --RAISERROR (@ErrMsg, 10, 1) WITH NOWAIT


  SET @SQL = 'use [' + @database_name + ']; 
              IF OBJECT_ID(''tempdb.dbo.#tmpsql_modules'') IS NOT NULL
                DROP TABLE #tmpsql_modules

              SELECT object_id, definition 
              INTO #tmpsql_modules 
              FROM sys.sql_modules AS sm
              WHERE (PATINDEX(''%'' + ''INDEX='' + ''%'', LOWER(sm.[definition]) COLLATE DATABASE_DEFAULT) > 0
                     OR
                     PATINDEX(''%'' + ''INDEX ='' + ''%'', LOWER(sm.[definition]) COLLATE DATABASE_DEFAULT) > 0)

              ;WITH CTE_1
              AS
              (
                SELECT DISTINCT Table_Name, Index_Name FROM tempdb.dbo.Tab_GetIndexInfo
                WHERE database_id = DB_ID()
              )
              SELECT QUOTENAME(DB_NAME()) AS DatabaseName, 
                     QUOTENAME(ss.name) AS [SchemaName], 
                     QUOTENAME(so.name) AS [ObjectName], 
                     so.type_desc [Type of object],
                     t.Index_Name AS IndexName,
                     CONVERT(XML, Tab1.Col1) AS [Object code definition]
              FROM CTE_1 AS t
              INNER JOIN #tmpsql_modules sm
              ON PATINDEX(''%'' + t.Table_Name + ''%'', LOWER(sm.[definition]) COLLATE DATABASE_DEFAULT) > 0
              AND PATINDEX(''%'' + t.Index_Name + ''%'', LOWER(sm.[definition]) COLLATE DATABASE_DEFAULT) > 0
              INNER JOIN sys.objects so 
              ON sm.[object_id] = so.[object_id]
              INNER JOIN sys.schemas ss 
              ON so.[schema_id] = ss.[schema_id]
              CROSS APPLY (SELECT CHAR(13)+CHAR(10) + sm.[definition] + CHAR(13)+CHAR(10) FOR XML RAW, ELEMENTS) AS Tab1(Col1)
              WHERE OBJECTPROPERTY(sm.[object_id],''IsMSShipped'') = 0
              OPTION (FORCE ORDER)'

  /*
  SELECT @SQL
  */
  INSERT INTO #tmp_Obj2
  EXEC (@SQL)
  
  FETCH NEXT FROM c_databases
  into @database_name
END
CLOSE c_databases
DEALLOCATE c_databases

SELECT 'Check 9 - Hard coded indexes' AS [Info],
       DatabaseName,
       SchemaName,
       ObjectName,
       IndexName,
       [Type of object],
       'Warning - Some sql objects have hard-coded references to indexes, those objects will fail if you drop the index.' AS [Comment],
       [Object code definition]
FROM #tmp_Obj2
