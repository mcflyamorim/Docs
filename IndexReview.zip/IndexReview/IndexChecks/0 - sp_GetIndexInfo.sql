USE [master];
GO

IF OBJECT_ID(N'sp_GetIndexInfo') IS NOT NULL
	 DROP PROCEDURE [dbo].sp_GetIndexInfo;
GO

/*

EXEC sp_GetIndexInfo @DatabaseName = 'KurierIntegracaoEvolutionPesquisa'

*/
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE PROC dbo.sp_GetIndexInfo
(
  @MinNumberOfRows bigint = 10, /* By default I am ignoring [small] (tables with less than 10 rows) tables */ 
  @DatabaseName NVARCHAR(200) = NULL /* By default I am returning information about all DBs */ 
)
AS
BEGIN
------------------------------------------------------------
/*
  Return information about statistics.
*/
-------------------------------------------------------------


SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SET LOCK_TIMEOUT 1000; /*1 second*/

DECLARE @statusMsg  VARCHAR(MAX) = ''

SET @statusMsg = 'Collecting cache index info...'
  RAISERROR(@statusMsg, 0, 42) WITH NOWAIT;

IF OBJECT_ID('tempdb.dbo.#tmpCacheMissingIndex1') IS NOT NULL
    DROP TABLE #tmpCacheMissingIndex1;

WITH XMLNAMESPACES
   (DEFAULT 'http://schemas.microsoft.com/sqlserver/2004/07/showplan')

SELECT 
       --n.query('.//MissingIndex') AS 'Missing_Index_Cache_Info',
       --CONVERT(XML, n.value('(@StatementText)[1]', 'VARCHAR(4000)')) AS 'Missing_Index_Cache_SQL',
       --n.value('(//MissingIndexGroup/@Impact)[1]', 'FLOAT') AS impact,
       OBJECT_ID(n.value('(//MissingIndex/@Database)[1]', 'VARCHAR(128)') + '.' +
           n.value('(//MissingIndex/@Schema)[1]', 'VARCHAR(128)') + '.' +
           n.value('(//MissingIndex/@Table)[1]', 'VARCHAR(128)')) AS OBJECT_ID
INTO #tmpCacheMissingIndex1
FROM
(
   SELECT query_plan
   FROM (
           SELECT DISTINCT plan_handle
           FROM sys.dm_exec_query_stats WITH(NOLOCK)
         ) AS qs
       OUTER APPLY sys.dm_exec_query_plan(qs.plan_handle) tp
   WHERE tp.query_plan.exist('//MissingIndex')=1
) AS tab (query_plan)
CROSS APPLY query_plan.nodes('//StmtSimple') AS q(n)
WHERE n.exist('QueryPlan/MissingIndexes') = 1;

IF OBJECT_ID('tempdb.dbo.#tmpCacheMissingIndex2') IS NOT NULL
    DROP TABLE #tmpCacheMissingIndex2;

SELECT OBJECT_ID, 
       COUNT(*) AS 'Number_of_missing_index_plans_cache'
  INTO #tmpCacheMissingIndex2
  FROM #tmpCacheMissingIndex1
  GROUP BY OBJECT_ID

CREATE CLUSTERED INDEX ix1 ON #tmpCacheMissingIndex2 (OBJECT_ID);

SET @statusMsg = 'Collecting BP usage info...'
RAISERROR(@statusMsg, 0, 42) WITH NOWAIT;

IF OBJECT_ID('tempdb.dbo.#tmpBufferDescriptors') IS NOT NULL
    DROP TABLE #tmpBufferDescriptors;

SELECT database_id,
       allocation_unit_id,
       CONVERT(DECIMAL(18, 2), (COUNT(*) * 8) / 1024.) AS CacheSizeMB,
       CONVERT(DECIMAL(18, 2), (SUM(CONVERT(FLOAT, free_space_in_bytes)) / 1024.) / 1024.) AS FreeSpaceMB
INTO #tmpBufferDescriptors
FROM sys.dm_os_buffer_descriptors
WHERE dm_os_buffer_descriptors.page_type IN ( 'data_page', 'index_page' )
GROUP BY database_id, allocation_unit_id;

CREATE CLUSTERED INDEX ix1 ON #tmpBufferDescriptors (database_id, allocation_unit_id);

IF OBJECT_ID('tempdb.dbo.Tab_GetIndexInfo') IS NOT NULL
  DROP TABLE tempdb.dbo.Tab_GetIndexInfo

CREATE TABLE tempdb.dbo.Tab_GetIndexInfo
(
  Database_ID INT,
  [Database_Name] [nvarchar] (128) NULL,
  [Schema_Name] [sys].[sysname] NOT NULL,
  [Table_Name] [sys].[sysname] NOT NULL,
  [Index_Name] [sys].[sysname] NULL,
  [Object_ID] INT,
  [Index_ID] INT,
  [Index_Type] [nvarchar] (60) NULL,
  TableHasLOB BIT,
  [Number_Rows] [bigint] NULL,
  [ReservedSizeInMB] [decimal] (18, 2) NULL,
  [reserved_page_count] [bigint] NULL,
  [used_page_count] [bigint] NULL,
  [in_row_data_page_count] [bigint] NULL,
  [Number_Of_Indexes_On_Table] [int] NULL,
  [avg_fragmentation_in_percent] [float] NULL,
  [fragment_count] [bigint] NULL,
  [avg_fragment_size_in_pages] [float] NULL,
  [page_count] [bigint] NULL,
  [avg_page_space_used_in_percent] [float] NULL,
  [record_count] [bigint] NULL,
  [ghost_record_count] [bigint] NULL,
  --[version_ghost_record_count] [bigint] NULL,
  [min_record_size_in_bytes] [int] NULL,
  [max_record_size_in_bytes] [int] NULL,
  [avg_record_size_in_bytes] [float] NULL,
  [forwarded_record_count] [bigint] NULL,
  [compressed_page_count] [bigint] NULL,
  --[version_record_count] [bigint] NULL,
  --[inrow_version_record_count] [bigint] NULL,
  --[inrow_diff_version_record_count] [bigint] NULL,
  [fill_factor] [tinyint] NOT NULL,
  [Buffer_Pool_SpaceUsed_MB] [decimal] (18, 2) NOT NULL,
  [Buffer_Pool_FreeSpace_MB] [decimal] (18, 2) NOT NULL,
  [Duplicated_Index_Identified] [varchar] (1) NOT NULL,
  [DMV_Missing_Index_Identified] [varchar] (1) NOT NULL,
  [Number_of_missing_index_plans_DMV] [int] NULL,
  [Cache_Missing_Index_Identified] [varchar] (1) NOT NULL,
  [Number_of_missing_index_plans_cache] [int] NULL,
  [Total Writes] [bigint] NULL,
  [Number_of_Reads] [bigint] NULL,
  [Index_was_never_used] [varchar] (1) NOT NULL,
  [indexed_columns] [xml] NULL,
  [included_columns] [xml] NULL,
  [is_unique] [bit] NULL,
  [ignore_dup_key] [bit] NULL,
  [is_primary_key] [bit] NULL,
  [is_unique_constraint] [bit] NULL,
  [is_padded] [bit] NULL,
  [is_disabled] [bit] NULL,
  [is_hypothetical] [bit] NULL,
  [allow_row_locks] [bit] NULL,
  [allow_page_locks] [bit] NULL,
  [has_filter] [bit] NULL,
  [filter_definition] [nvarchar] (max) NULL,
  [create_date] [datetime] NOT NULL,
  [modify_date] [datetime] NOT NULL,
  [uses_ansi_nulls] [bit] NULL,
  [is_replicated] [bit] NULL,
  [has_replication_filter] [bit] NULL,
  [text_in_row_limit] [int] NULL,
  [large_value_types_out_of_row] [bit] NULL,
  [is_tracked_by_cdc] [bit] NULL,
  [lock_escalation_desc] [nvarchar] (60) NULL,
  [partition_number] [int] NOT NULL,
  [data_compression_desc] [nvarchar] (60) NULL,
  [user_seeks] [bigint] NULL,
  [user_scans] [bigint] NULL,
  [user_lookups] [bigint] NULL,
  [user_updates] [bigint] NULL,
  [last_user_seek] [datetime] NULL,
  [last_user_scan] [datetime] NULL,
  [last_user_lookup] [datetime] NULL,
  [last_user_update] [datetime] NULL,
  [leaf_insert_count] [bigint] NULL,
  [leaf_delete_count] [bigint] NULL,
  [leaf_update_count] [bigint] NULL,
  [leaf_ghost_count] [bigint] NULL,
  [nonleaf_insert_count] [bigint] NULL,
  [nonleaf_delete_count] [bigint] NULL,
  [nonleaf_update_count] [bigint] NULL,
  [leaf_allocation_count] [bigint] NULL,
  [nonleaf_allocation_count] [bigint] NULL,
  [leaf_page_merge_count] [bigint] NULL,
  [nonleaf_page_merge_count] [bigint] NULL,
  [range_scan_count] [bigint] NULL,
  [singleton_lookup_count] [bigint] NULL,
  [forwarded_fetch_count] [bigint] NULL,
  [lob_fetch_in_pages] [bigint] NULL,
  [lob_fetch_in_bytes] [bigint] NULL,
  [lob_orphan_create_count] [bigint] NULL,
  [lob_orphan_insert_count] [bigint] NULL,
  [row_overflow_fetch_in_pages] [bigint] NULL,
  [row_overflow_fetch_in_bytes] [bigint] NULL,
  [column_value_push_off_row_count] [bigint] NULL,
  [column_value_pull_in_row_count] [bigint] NULL,
  [row_lock_count] [bigint] NULL,
  [row_lock_wait_count] [bigint] NULL,
  [row_lock_wait_in_ms] [bigint] NULL,
  [page_lock_count] [bigint] NULL,
  [page_lock_wait_count] [bigint] NULL,
  [page_lock_wait_in_ms] [bigint] NULL,
  [index_lock_escaltion_attempt_count] [bigint] NULL,
  [index_lock_escaltion_count] [bigint] NULL,
  [page_latch_wait_count] [bigint] NULL,
  [page_latch_wait_in_ms] [bigint] NULL,
  [page_io_latch_wait_count] [bigint] NULL,
  [page_io_latch_wait_in_ms] [bigint] NULL,
  [tree_page_latch_wait_count] [bigint] NULL,
  [tree_page_latch_wait_in_ms] [bigint] NULL,
  [tree_page_io_latch_wait_count] [bigint] NULL,
  [tree_page_io_latch_wait_in_ms] [bigint] NULL,
  [KeyCols_data_length_bytes] INT,
  Key_has_GUID INT,
  IsTablePartitioned Bit
)

IF OBJECT_ID('tempdb.dbo.#db') IS NOT NULL
  DROP TABLE #db

SELECT d1.[name] into #db
FROM sys.databases d1
where d1.state_desc = 'ONLINE' and is_read_only = 0
and d1.name not in ('tempdb', 'master', 'model', 'msdb')
AND (d1.name = @DatabaseName OR @DatabaseName IS NULL)

DECLARE @SQL VarCHar(MAX)
declare @database_name sysname

DECLARE c_databases CURSOR read_only FOR
    SELECT [name] FROM #db
OPEN c_databases

FETCH NEXT FROM c_databases
into @database_name
WHILE @@FETCH_STATUS = 0
BEGIN
  SET @statusMsg = 'Working on DB - [' + @database_name + ']'
  RAISERROR (@statusMsg, 10, 1) WITH NOWAIT

  SET @SQL = 'use [' + @database_name + ']; ' + 

  'DECLARE @statusMsg  VARCHAR(MAX) = ''''
  
  SET NOCOUNT ON;
  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

  SET @statusMsg = ''Collecting duplicated index info...''
  RAISERROR(@statusMsg, 0, 42) WITH NOWAIT;

  IF OBJECT_ID(''tempdb.dbo.#tmpDuplicatedIndex'') IS NOT NULL
      DROP TABLE #tmpDuplicatedIndex;

  BEGIN TRY
    SELECT DISTINCT i.object_id, i.index_id
    INTO #tmpDuplicatedIndex
    FROM sys.tables AS t 
    JOIN sys.indexes AS i
	    ON t.object_id = i.object_id
    JOIN sys.index_columns ic 
	    ON ic.object_id = i.object_id 
		    AND ic.index_id = i.index_id 
		    AND ic.index_column_id = 1  
    JOIN sys.columns AS c 
	    ON c.object_id = ic.object_id 
		    AND c.column_id = ic.column_id      
    JOIN sys.schemas AS s 
	    ON t.schema_id = s.schema_id
    CROSS APPLY
    (
	    SELECT 
	       ind.index_id
	       ,ind.name
	    FROM sys.indexes AS ind 
	    JOIN sys.index_columns AS ico 
	       ON ico.object_id = ind.object_id
	       AND ico.index_id = ind.index_id
	       AND ico.index_column_id = 1  
	    WHERE ind.object_id = i.object_id 
	       AND ind.index_id > i.index_id
	       AND ico.column_id = ic.column_id
        AND ISNULL(ind.filter_definition,'''') = ISNULL(i.filter_definition,'''')
    ) DupliIDX    
    WHERE i.index_id > 1

    CREATE CLUSTERED INDEX ix1 ON #tmpDuplicatedIndex (object_id, index_id);

  END TRY
		BEGIN CATCH
    SET @statusMsg = ''Error trying to run Duplicated index query... Timeout... Continuing without this info.''
    RAISERROR(@statusMsg, 0, 42) WITH NOWAIT;
		END CATCH

  SET @statusMsg = ''Collecting fragmentation index info...''
  RAISERROR(@statusMsg, 0, 42) WITH NOWAIT;

  SET LOCK_TIMEOUT 5000; /*5 seconds*/
  DECLARE @objname sysname, @idxname sysname, @object_id INT, @index_id INT, @row_count BIGINT, @tot INT, @i INT

  IF OBJECT_ID(''tempdb.dbo.#tmpIndexFrag'') IS NOT NULL
    DROP TABLE #tmpIndexFrag;

  CREATE TABLE [#tmpIndexFrag]
  (
    [database_id] SMALLINT,
    [object_id] INT,
    [index_id] INT,
    [avg_fragmentation_in_percent] FLOAT,
    [fragment_count] BIGINT,
    [avg_fragment_size_in_pages] FLOAT,
    [page_count] BIGINT,
    [avg_page_space_used_in_percent] FLOAT,
    [record_count] BIGINT,
    [ghost_record_count] BIGINT,
    [min_record_size_in_bytes] INT,
    [max_record_size_in_bytes] INT,
    [avg_record_size_in_bytes] FLOAT,
    [forwarded_record_count] BIGINT,
    [compressed_page_count] BIGINT
  )

  IF OBJECT_ID(''tempdb.dbo.#tmpIndexFrag_Cursor'') IS NOT NULL
    DROP TABLE #tmpIndexFrag_Cursor;

  SELECT objects.name AS objname, indexes.name AS idxname, indexes.object_id, indexes.index_id, dm_db_partition_stats.row_count
  INTO #tmpIndexFrag_Cursor
  FROM sys.indexes
  INNER JOIN sys.objects
  ON objects.object_id = indexes.object_id
  INNER JOIN sys.dm_db_partition_stats
  ON dm_db_partition_stats.object_id = indexes.object_id
  AND dm_db_partition_stats.index_id = indexes.index_id
  WHERE objects.type = ''U''
  AND indexes.type not in (5, 6) /*ignoring columnstore indexes*/
  AND dm_db_partition_stats.partition_number = 1

  SET @tot = @@ROWCOUNT

  DECLARE c_allrows CURSOR READ_ONLY FOR
  SELECT * FROM #tmpIndexFrag_Cursor
  ORDER BY row_count ASC

  OPEN c_allrows

  FETCH NEXT FROM c_allrows
  INTO @objname, @idxname, @object_id, @index_id, @row_count

  SET @i = 0
  WHILE @@FETCH_STATUS = 0
  BEGIN
    SET @i = @i + 1

    SET @statusMsg = ''Working on index '' + CONVERT(VARCHAR, @i) + '' of '' + CONVERT(VARCHAR, @tot) + '': ObjName = '' + QUOTENAME(@objname) + '' | IndexName = '' + QUOTENAME(@idxname) + '' | RowCount = '' + CONVERT(VARCHAR(50), @row_count)
    RAISERROR (@statusMsg, 10, 1) WITH NOWAIT

    BEGIN TRY
      INSERT INTO #tmpIndexFrag
      SELECT
        dm_db_index_physical_stats.database_id,
        dm_db_index_physical_stats.object_id,
        dm_db_index_physical_stats.index_id,
        dm_db_index_physical_stats.avg_fragmentation_in_percent,
        dm_db_index_physical_stats.fragment_count,
        dm_db_index_physical_stats.avg_fragment_size_in_pages,
        dm_db_index_physical_stats.page_count,
        dm_db_index_physical_stats.avg_page_space_used_in_percent,
        dm_db_index_physical_stats.record_count,
        dm_db_index_physical_stats.ghost_record_count,
        dm_db_index_physical_stats.min_record_size_in_bytes,
        dm_db_index_physical_stats.max_record_size_in_bytes,
        dm_db_index_physical_stats.avg_record_size_in_bytes,
        dm_db_index_physical_stats.forwarded_record_count,
        dm_db_index_physical_stats.compressed_page_count
      FROM sys.dm_db_index_physical_stats(DB_ID(), @object_id, @index_id, NULL, ''SAMPLED'')
      WHERE dm_db_index_physical_stats.alloc_unit_type_desc = ''IN_ROW_DATA''
      AND index_level = 0 /*leaf-level nodes only*/
      AND partition_number = 1;
    END TRY
    BEGIN CATCH
      SET @statusMsg = ''Error trying to run fragmentation index query... Timeout... Skipping collection data about this table/index.''
      RAISERROR (@statusMsg, 10, 1) WITH NOWAIT
    END CATCH

    FETCH NEXT FROM c_allrows
    INTO @objname, @idxname, @object_id, @index_id, @row_count
  END
  CLOSE c_allrows
  DEALLOCATE c_allrows

  SET LOCK_TIMEOUT -1;

  SELECT DB_ID() AS database_id,
         DB_NAME() AS ''Database_Name'',
         sc.name AS ''Schema_Name'',
         t.name AS ''Table_Name'',
         i.name AS ''Index_Name'',
         t.object_id,
         i.index_id,
         i.type_desc AS ''Index_Type'',
         ISNULL(t1.TableHasLOB, 0) AS TableHasLOB,
         p.rows AS ''Number_Rows'',
         tSize.ReservedSizeInMB,
         tSize.reserved_page_count,
         tSize.used_page_count,
         tSize.in_row_data_page_count,
         tNumerOfIndexes.Cnt AS ''Number_Of_Indexes_On_Table'',
         #tmpIndexFrag.avg_fragmentation_in_percent,
         #tmpIndexFrag.fragment_count,
         #tmpIndexFrag.avg_fragment_size_in_pages,
         #tmpIndexFrag.page_count,
         #tmpIndexFrag.avg_page_space_used_in_percent,
         #tmpIndexFrag.record_count,
         #tmpIndexFrag.ghost_record_count,
         --#tmpIndexFrag.version_ghost_record_count,
         #tmpIndexFrag.min_record_size_in_bytes,
         #tmpIndexFrag.max_record_size_in_bytes,
         #tmpIndexFrag.avg_record_size_in_bytes,
         #tmpIndexFrag.forwarded_record_count,
         #tmpIndexFrag.compressed_page_count,
         --#tmpIndexFrag.version_record_count,
         --#tmpIndexFrag.inrow_version_record_count,
         --#tmpIndexFrag.inrow_diff_version_record_count,
         i.fill_factor,
         ISNULL(bp.CacheSizeMB, 0) AS ''Buffer_Pool_SpaceUsed_MB'',
         ISNULL(bp.FreeSpaceMB, 0) AS ''Buffer_Pool_FreeSpace_MB'',
         CASE
             WHEN #tmpDuplicatedIndex.object_id IS NULL THEN
                 ''N''
             ELSE
                 ''Y''
         END AS ''Duplicated_Index_Identified'',
         CASE
             WHEN mid.database_id IS NULL THEN
                 ''N''
             ELSE
                 ''Y''
         END AS ''DMV_Missing_Index_Identified'',
         mid.Number_of_missing_index_plans_DMV,
         CASE
             WHEN #tmpCacheMissingIndex2.Number_of_missing_index_plans_cache IS NULL THEN
                 ''N''
             ELSE
                 ''Y''
         END AS ''Cache_Missing_Index_Identified'',
         #tmpCacheMissingIndex2.Number_of_missing_index_plans_cache,
         ius.user_updates AS [Total Writes], 
         ius.user_seeks + ius.user_scans + ius.user_lookups AS ''Number_of_Reads'',
         CASE
             WHEN ius.user_seeks + ius.user_scans + ius.user_lookups = 0 THEN
                 ''Y''
             ELSE
                 ''N''
         END AS ''Index_was_never_used'',
         CONVERT(XML, ISNULL(REPLACE(REPLACE(REPLACE(
                                (
                                    SELECT c.name AS ''columnName''
                                    FROM sys.index_columns AS sic
                                        JOIN sys.columns AS c
                                            ON c.column_id = sic.column_id
                                               AND c.object_id = sic.object_id
                                    WHERE sic.object_id = i.object_id
                                          AND sic.index_id = i.index_id
                                          AND is_included_column = 0
                                    ORDER BY sic.index_column_id
                                    FOR XML RAW
                                ),
                                ''"/><row columnName="'',
                                '', ''
                                       ),
                                ''<row columnName="'',
                                ''''
                               ),
                        ''"/>'',
                        ''''
                       ),
                ''''
               )) AS ''indexed_columns'',
         CONVERT(XML, ISNULL(REPLACE(REPLACE(REPLACE(
                                (
                                    SELECT c.name AS ''columnName''
                                    FROM sys.index_columns AS sic
                                        JOIN sys.columns AS c
                                            ON c.column_id = sic.column_id
                                               AND c.object_id = sic.object_id
                                    WHERE sic.object_id = i.object_id
                                          AND sic.index_id = i.index_id
                                          AND is_included_column = 1
                                    ORDER BY sic.index_column_id
                                    FOR XML RAW
                                ),
                                ''"/><row columnName="'',
                                '', ''
                                       ),
                                ''<row columnName="'',
                                ''''
                               ),
                        ''"/>'',
                        ''''
                       ),
                ''''
               )) AS ''included_columns'',
         i.is_unique,
         i.ignore_dup_key,
         i.is_primary_key,
         i.is_unique_constraint,
         i.is_padded,
         i.is_disabled,
         i.is_hypothetical,
         i.allow_row_locks,
         i.allow_page_locks,
         i.has_filter,
         i.filter_definition,
         t.create_date,
         t.modify_date,
         t.uses_ansi_nulls,
         t.is_replicated,
         t.has_replication_filter,
         t.text_in_row_limit,
         t.large_value_types_out_of_row,
         t.is_tracked_by_cdc,
         t.lock_escalation_desc,
         --t.is_filetable,
         --t.is_memory_optimized,
         --t.durability_desc,
         --t.temporal_type_desc,
         --t.is_remote_data_archive_enabled,
         p.partition_number,
         p.data_compression_desc,
         ius.user_seeks,
         ius.user_scans,
         ius.user_lookups,
         ius.user_updates,
         ius.last_user_seek,
         ius.last_user_scan,
         ius.last_user_lookup,
         ius.last_user_update,
         ios.leaf_insert_count,
         ios.leaf_delete_count,
         ios.leaf_update_count,
         ios.leaf_ghost_count,
         ios.nonleaf_insert_count,
         ios.nonleaf_delete_count,
         ios.nonleaf_update_count,
         ios.leaf_allocation_count,
         ios.nonleaf_allocation_count,
         ios.leaf_page_merge_count,
         ios.nonleaf_page_merge_count,
         ios.range_scan_count,
         ios.singleton_lookup_count,
         ios.forwarded_fetch_count,
         ios.lob_fetch_in_pages,
         ios.lob_fetch_in_bytes,
         ios.lob_orphan_create_count,
         ios.lob_orphan_insert_count,
         ios.row_overflow_fetch_in_pages,
         ios.row_overflow_fetch_in_bytes,
         ios.column_value_push_off_row_count,
         ios.column_value_pull_in_row_count,
         ios.row_lock_count,
         ios.row_lock_wait_count,
         ios.row_lock_wait_in_ms,
         ios.page_lock_count,
         ios.page_lock_wait_count,
         ios.page_lock_wait_in_ms,
         ios.index_lock_promotion_attempt_count AS index_lock_escaltion_attempt_count,
         ios.index_lock_promotion_count AS index_lock_escaltion_count,
         ios.page_latch_wait_count,
         ios.page_latch_wait_in_ms,
         ios.page_io_latch_wait_count,
         ios.page_io_latch_wait_in_ms,
         ios.tree_page_latch_wait_count,
         ios.tree_page_latch_wait_in_ms,
         ios.tree_page_io_latch_wait_count,
         ios.tree_page_io_latch_wait_in_ms,
         (SELECT SUM(CASE sty.name WHEN ''nvarchar'' THEN sc.max_length/2 ELSE sc.max_length END) 
          FROM sys.indexes AS ii
		        INNER JOIN sys.tables AS tt ON tt.[object_id] = ii.[object_id]
		        INNER JOIN sys.schemas ss ON ss.[schema_id] = tt.[schema_id]
		        INNER JOIN sys.index_columns AS sic ON sic.object_id = tt.object_id AND sic.index_id = ii.index_id
		        INNER JOIN sys.columns AS sc ON sc.object_id = tt.object_id AND sc.column_id = sic.column_id
		        INNER JOIN sys.types AS sty ON sc.user_type_id = sty.user_type_id
		        WHERE ii.[object_id] = i.[object_id] 
            AND ii.index_id = i.index_id 
            AND sic.key_ordinal > 0) AS [KeyCols_data_length_bytes],
         (SELECT COUNT(sty.name) 
            FROM sys.indexes AS ii
		         INNER JOIN sys.tables AS tt ON tt.[object_id] = ii.[object_id]
		         INNER JOIN sys.schemas ss ON ss.[schema_id] = tt.[schema_id]
		         INNER JOIN sys.index_columns AS sic ON sic.object_id = i.object_id AND sic.index_id = i.index_id
		         INNER JOIN sys.columns AS sc ON sc.object_id = tt.object_id AND sc.column_id = sic.column_id
		         INNER JOIN sys.types AS sty ON sc.user_type_id = sty.user_type_id
		         WHERE i.[object_id] = ii.[object_id] 
           AND i.index_id = ii.index_id 
           AND sic.is_included_column = 0 
           AND sty.name = ''uniqueidentifier'') AS [Key_has_GUID],
         CASE 
           WHEN EXISTS(SELECT *
                         FROM sys.partitions pp
                        WHERE pp.partition_number > 1
                          AND pp.object_id = i.object_Id
                          AND pp.index_id IN (0, 1)) THEN 1
           ELSE 0
         END AS IsTablePartitioned
  FROM sys.indexes i WITH (NOLOCK)
      INNER JOIN sys.tables t
          ON t.object_id = i.object_id
      INNER JOIN sys.schemas sc WITH (NOLOCK)
          ON sc.schema_id = t.schema_id
      INNER JOIN sys.partitions AS p
          ON i.object_id = p.object_id
             AND i.index_id = p.index_id
             AND p.partition_number = 1
      INNER JOIN sys.allocation_units AS au
          ON au.container_id = p.hobt_id
         AND au.type_desc = ''IN_ROW_DATA''
      LEFT OUTER JOIN #tmpCacheMissingIndex2
        ON #tmpCacheMissingIndex2.OBJECT_ID = i.object_id
      LEFT OUTER JOIN #tmpDuplicatedIndex
         ON #tmpDuplicatedIndex.index_id = i.index_id
        AND #tmpDuplicatedIndex.object_id = i.object_id
      OUTER APPLY (SELECT TOP 1 
                          1 AS TableHasLOB
                  FROM sys.tables
                 INNER JOIN sys.all_columns
                    ON all_columns.object_id = tables.object_id
                  WHERE i.Object_ID = tables.object_id
                    AND COLUMNPROPERTY(all_columns.object_id, all_columns.name, ''Precision'') = -1) as t1
      CROSS APPLY
      (
          SELECT CONVERT(DECIMAL(18, 2), SUM((st.reserved_page_count * 8) / 1024.)) ReservedSizeInMB,
                 SUM(st.reserved_page_count) AS reserved_page_count,
                 SUM(st.used_page_count) AS used_page_count,
                 SUM(st.in_row_data_page_count) AS in_row_data_page_count
          FROM sys.dm_db_partition_stats st
          WHERE i.object_id = st.object_id
                AND i.index_id = st.index_id
                AND p.partition_number = st.partition_number
                AND st.partition_number = 1
      ) AS tSize
      LEFT OUTER JOIN sys.dm_db_index_usage_stats ius WITH (NOLOCK)
          ON ius.index_id = i.index_id
             AND ius.object_id = i.object_id
             AND ius.database_id = DB_ID()
      OUTER APPLY (SELECT TOP 1 * FROM sys.dm_db_index_operational_stats(DB_ID(), i.object_id, i.index_id, 1)) AS ios
      LEFT OUTER JOIN #tmpBufferDescriptors AS bp
          ON bp.database_id = DB_ID()
         AND bp.allocation_unit_id = au.allocation_unit_id
      LEFT OUTER JOIN #tmpIndexFrag
          ON i.object_id = #tmpIndexFrag.object_id
             AND i.index_id = #tmpIndexFrag.index_id
             AND #tmpIndexFrag.database_id = DB_ID()
      LEFT OUTER JOIN
      (
          SELECT database_id,
                 object_id,
                 COUNT(*) AS Number_of_missing_index_plans_DMV
          FROM sys.dm_db_missing_index_details
          GROUP BY database_id,
                   object_id
      ) AS mid
          ON mid.database_id = DB_ID()
             AND mid.object_id = i.object_id
      CROSS APPLY
      (
          SELECT COUNT(*) AS Cnt
          FROM sys.indexes i1
          WHERE i.object_id = i1.object_id
      ) AS tNumerOfIndexes
  WHERE OBJECTPROPERTY(i.[object_id], ''IsUserTable'') = 1
  ORDER BY tSize.ReservedSizeInMB DESC
  '

  /*
    SELECT @SQL
  */
  INSERT INTO tempdb.dbo.Tab_GetIndexInfo
  EXEC (@SQL)
  
  FETCH NEXT FROM c_databases
  into @database_name
END
CLOSE c_databases
DEALLOCATE c_databases

CREATE UNIQUE CLUSTERED INDEX ix1 ON tempdb.dbo.Tab_GetIndexInfo(Database_ID, Object_ID, Index_ID)
--SELECT * FROM tempdb.dbo.Tab_GetIndexInfo
--ORDER BY ReservedSizeInMB DESC
END
GO

EXEC [sys].[sp_MS_marksystemobject] 'sp_GetIndexInfo';
GO