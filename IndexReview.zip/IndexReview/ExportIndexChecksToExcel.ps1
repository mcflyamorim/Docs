﻿<#
    .SYNOPSIS
    Export SQL Server Index Checks to Excel
    .DESCRIPTION
    Export SQL Server Index Checks to Excel
    .NOTES
    .PARAMETER SqlInstance
    SQL Server instance name, use the full name, for instance, if server is ServerA and instance is SQL2005, use "ServerA\SQL2005"
    .PARAMETER UserName
    SQL Server LoginName to connect on SQL Server, if not specified WinAuth will be used.
    .PARAMETER Password
    SQL Server password to connect on SQL Server, if not specified WinAuth will be used.
    .PARAMETER Database
    Specify a specific Database, if not specified it will collect info about all online user DBs.
    .PARAMETER LogFilePath
    Path I'll use to create the "SQLServerIndexsCheck_<>.xlsx" file with script output, default is $PSScriptRoot
    .LINK
    https://github.com/mcflyamorim
    .EXAMPLE
    Open a PowerShell console and run the following command:
    PS C:\>& "C:\temp\ExportIndexChecksToExcel.ps1" -SQLInstance "SQL2019" -LogFilePath "C:\temp\" -Force_sp_GetIndexInfo_Execution
    .EXAMPLE
    Open a PowerShell console and run the following command:
    PS C:\>& "C:\temp\ExportIndexChecksToExcel.ps1" -SQLInstance "DELLFABIANO\SQL2019" -UserName "sa" -Password "@bc12345" -LogFilePath "C:\temp\" -Force_sp_GetIndexInfo_Execution
#>
param
(
    [parameter(Mandatory=$false)]
    [String] $SQLInstance = "DELLFABIANO\SQL2019",
    [String]$UserName,
    [String]$Password,
    [String]$Database,
    [parameter(Mandatory=$false)]
    [String] $LogFilePath = "C:\temp",
    [parameter(Mandatory=$false)]
    [switch]$Force_sp_GetIndexInfo_Execution
)
function Write-Msg {
    param (
        [string]$Message = '',
		[string]$Level = 'Output', # Output|Warning|Error
        [switch]$VerboseMsg
    )
    $ForegroundColor = switch ($Level) {
        'Output'  {'Cyan'}
        'Warning' {'Yellow'}
        'Error'   {'Red'}
        Default {'Cyan'}
    }
    $dt = Get-Date -format "yyyy-MM-dd hh:mm:ss"
    if (($ShowVerboseMessages) -and ($VerboseMsg)){
        Write-Host ("[{0}] - [$Level] - {1} `r" -f $dt, $Message) -ForegroundColor $ForegroundColor
    }
    elseif ($false -eq $VerboseMsg) {
        Write-Host ("[{0}] - [$Level] - {1} `r" -f $dt, $Message) -ForegroundColor $ForegroundColor
    }
}

function fnReturn {
    try {Stop-Transcript -ErrorAction SilentlyContinue -WhatIf:$false | Out-Null} catch{}
    exit
}

Clear-Host

#$Database = 'Northwind'
$Force_sp_GetIndexInfo_Execution = $true

# Params
$SQLInstance = 'dellfabiano\sql2019'
$IndexChecksFolderPath = "$PSScriptRoot\IndexChecks\"

# Check if $LogFilePath directory exists, if not, create it.
if ($LogFilePath -notlike '*\'){
    $LogFilePath = $LogFilePath + "\"
}
if( ! ( Test-Path $LogFilePath ) )
{
	New-Item $LogFilePath -type Directory | Out-Null
}

$CurrentDate = Get-Date
$IndexChecksFolderPath = "$PSScriptRoot\IndexChecks\"
$instance = $SQLInstance
$SQLInstance = $SQLInstance.Replace('\','').Replace('/','').Replace(':','').Replace('*','').Replace('?','').Replace('"','').Replace('<','').Replace('>','').Replace('|','')
$FilePrefix = $SQLInstance + "_" + $CurrentDate.ToString("yyyyMMdd") + "_" + $CurrentDate.ToString("hhmm") + ".xlsx"
$FileOutput = $LogFilePath + "SQLServerIndexCheck_" + $FilePrefix

# Print input parameters values
$dt = Get-Date -Format 'yyyy-MM-dd hh:mm:ss'; 
Write-Host "$dt InputParameter value - Writing output to $LogFilePath" -ForegroundColor Yellow
Write-Host "$dt InputParameter value - Specified SQLInstance is $instance" -ForegroundColor Yellow
Write-Host "$dt Exporting data to $FileOutput" -ForegroundColor Yellow

# Installing ImportExcel module...
# Module may be installed but not imported into the PS scope session... if so, call import-module
if(Get-Module -Name ImportExcel -ListAvailable){
    Import-Module ImportExcel -Force -ErrorAction Stop
}
if(-not (Get-Module -Name ImportExcel))
{
    Write-Msg -Message "ImportExcel is not installed, trying to install" -VerboseMsg
    Write-Msg -Message "Trying to manually install ImportExcel from Util folder" -VerboseMsg
    if (Test-Path -Path "$ScriptPath\Util\ImportExcel\ImportExcel.zip" -PathType Leaf){
        try {
            foreach ($modpath in $($env:PSModulePath -split [IO.Path]::PathSeparator)) {
                #Grab the user's default home directory module path for later
                if ($modpath -like "*$([Environment]::UserName)*") {
                    $userpath = $modpath
                }
                try {
                    $temppath = Join-Path -Path $modpath -ChildPath "ImportExcel"
                    $localpath = (Get-ChildItem $temppath -ErrorAction Stop).FullName
                } catch {
                    $localpath = $null
                }
            }
            if ($null -eq $localpath) {
                if (!(Test-Path -Path $userpath)) {
                    try {
                        Write-Msg -Message "Creating directory: $userpath" -VerboseMsg
                        New-Item -Path $userpath -ItemType Directory | Out-Null
                    } catch {
                        throw "Can't create $userpath. You may need to Run as Administrator: $_"
                    }
                }
                # In case ImportExcel is not currently installed in any PSModulePath put it in the $userpath
                if (Test-Path -Path $userpath) {
                    $localpath = Join-Path -Path $userpath -ChildPath "ImportExcel"
                }
            } else {
                Write-Msg -Message "Updating current install" -VerboseMsg
            }
            $path = $localpath
            if (!(Test-Path -Path $path)) {
                try {
                    Write-Msg -Message "Creating directory: $path" -VerboseMsg
                    New-Item -Path $path -ItemType Directory | Out-Null
                } catch {
                    throw "Can't create $path. You may need to Run as Administrator: $_"
                }
            }

            $ImportExcelDir = "$path"
            $OutZip = Join-Path $ImportExcelDir 'ImportExcel.zip'
            Copy-Item -Path "$ScriptPath\Util\ImportExcel\ImportExcel.zip" -Destination $OutZip -ErrorAction Stop | Out-Null
            if (Test-Path $OutZip) {
                Write-Msg -Message "Trying to unzip $OutZip file" -VerboseMsg
                Add-Type -AssemblyName 'System.Io.Compression.FileSystem'
                [io.compression.zipfile]::ExtractToDirectory($OutZip, $ImportExcelDir)
                if (Test-Path "$ImportExcelDir\ImportExcel.psd1") {
                    Write-Msg -Message "File extracted to $ImportExcelDir" -VerboseMsg
                }
            }
            else {
                throw "$OutZip file was not found"
            }
            Import-Module $ImportExcelDir -Force -ErrorAction Stop
            Write-Msg -Message "ImportExcel installed successfully" -VerboseMsg
        } catch {
            Write-Msg -Message "Error trying to install ImportExcel from Util folder" -Level Error
            Write-Msg -Message "ErrorMessage: $($_.Exception.Message)" -Level Error
        }
    }
    else {
        Write-Msg "Could not find file $ScriptPath\Util\ImportExcel\ImportExcel.zip, please make sure you've copied ImportExcel.zip file to Util folder of this script." -Level Error
        fnReturn
    }
    if (-not (Get-Module -Name ImportExcel)) {
        try {
            Write-Msg -Message "Trying to install ImportExcel via Install-Module" -VerboseMsg
            Install-Module ImportExcel -Scope CurrentUser -Confirm:$False -Force -ErrorAction Stop | Out-Null
            Import-Module ImportExcel -Force -ErrorAction Stop
        } catch {
            Write-Msg -Message "Error trying to install ImportExcel via Install-Module" -Level Warning
            Write-Msg -Message "ErrorMessage: $($_.Exception.Message)" -Level Warning
        }
    }
}
if (-not (Get-Module -Name ImportExcel)) {
    Write-Msg -Message "ImportExcel is not installed, please install it before continue" -Level Error
    fnReturn
}

# Installing SqlServer module...
# Module may be installed but not imported into the PS scope session... if so, call import-module
if(Get-Module -Name SqlServer -ListAvailable){
    Import-Module SqlServer -Force -ErrorAction Stop
}
if(-not (Get-Module -Name SqlServer))
{
    Write-Msg -Message "SqlServer is not installed, trying to install" -VerboseMsg
    Write-Msg -Message "Trying to manually install SqlServer from Util folder" -VerboseMsg
    if (Test-Path -Path "$ScriptPath\Util\SqlServer\SqlServer.zip" -PathType Leaf){
        try {
            foreach ($modpath in $($env:PSModulePath -split [IO.Path]::PathSeparator)) {
                #Grab the user's default home directory module path for later
                if ($modpath -like "*$([Environment]::UserName)*") {
                    $userpath = $modpath
                }
                try {
                    $temppath = Join-Path -Path $modpath -ChildPath "SqlServer"
                    $localpath = (Get-ChildItem $temppath -ErrorAction Stop).FullName
                } catch {
                    $localpath = $null
                }
            }
            if ($null -eq $localpath) {
                if (!(Test-Path -Path $userpath)) {
                    try {
                        Write-Msg -Message "Creating directory: $userpath" -VerboseMsg
                        New-Item -Path $userpath -ItemType Directory | Out-Null
                    } catch {
                        throw "Can't create $userpath. You may need to Run as Administrator: $_"
                    }
                }
                # In case SqlServer is not currently installed in any PSModulePath put it in the $userpath
                if (Test-Path -Path $userpath) {
                    $localpath = Join-Path -Path $userpath -ChildPath "SqlServer"
                }
            } else {
                Write-Msg -Message "Updating current install" -VerboseMsg
            }
            $path = $localpath
            if (!(Test-Path -Path $path)) {
                try {
                    Write-Msg -Message "Creating directory: $path" -VerboseMsg
                    New-Item -Path $path -ItemType Directory | Out-Null
                } catch {
                    throw "Can't create $path. You may need to Run as Administrator: $_"
                }
            }

            $SqlServerDir = "$path"
            $OutZip = Join-Path $SqlServerDir 'SqlServer.zip'
            Copy-Item -Path "$ScriptPath\Util\SqlServer\SqlServer.zip" -Destination $OutZip -ErrorAction Stop | Out-Null
            if (Test-Path $OutZip) {
                Write-Msg -Message "Trying to unzip $OutZip file" -VerboseMsg
                Add-Type -AssemblyName 'System.Io.Compression.FileSystem'
                [io.compression.zipfile]::ExtractToDirectory($OutZip, $SqlServerDir)
                if (Test-Path "$SqlServerDir\SqlServer.psd1") {
                    Write-Msg -Message "File extracted to $SqlServerDir" -VerboseMsg
                }
            }
            else {
                throw "$OutZip file was not found"
            }
            Import-Module $SqlServerDir -Force -ErrorAction Stop
        } catch {
            Write-Msg -Message "Error trying to install SqlServer from Util folder" -Level Error
            Write-Msg -Message "ErrorMessage: $($_.Exception.Message)" -Level Error
        }
    }
    else {
        Write-Msg "Could not find file $ScriptPath\Util\SqlServer\SqlServer.zip, please make sure you've copied SqlServer.zip file to Util folder of this script." -Level Error
        fnReturn
    }
    if(-not (Get-Module -Name SqlServer)){
        try {
            Write-Msg -Message "Trying to install SqlServer via Install-Module" -VerboseMsg
            Install-Module SqlServer -Scope CurrentUser -Confirm:$False -Force -ErrorAction Stop | Out-Null
            Import-Module SqlServer -Force -ErrorAction Stop
        } catch {
            Write-Msg -Message "Error trying to install SqlServer via Install-Module" -Level Error
            Write-Msg -Message "ErrorMessage: $($_.Exception.Message)" -Level Error
        }
    }
}
if (-not (Get-Module -Name SqlServer)) {
    Write-Msg -Message "SqlServer is not installed, please install it before continue" -Level Error
    fnReturn
}

$Params = @{}
if ( $UserName -and $Password ) {
    $Params.Username = $UserName
    $Params.Password = $Password
}

try
{
    #If -Force_sp_GetIndexInfo_Execution is set, recreate and run proc sp_GetIndexInfo  
	if ($Force_sp_GetIndexInfo_Execution) {
        $dt = Get-Date -Format 'yyyy-MM-dd hh:mm:ss'; 
		Write-Warning "$dt Running proc sp_GetIndexInfo, this may take a while to run, be patient."

        $TsqlFile = $IndexChecksFolderPath + '0 - sp_GetIndexInfo.sql'
		Invoke-SqlCmd @Params –ServerInstance $instance -Database "master" -QueryTimeout 7200 <#2 hours#> -InputFile $TsqlFile -ErrorAction Stop

        #Using -Verbose to capture SQL Server message output
		if ($Database){
            $Query1 = "EXEC master.dbo.sp_GetIndexInfo @DatabaseName = '$Database'"
            Invoke-SqlCmd @Params –ServerInstance $instance -Database "master" -QueryTimeout 7200 <#2 hours#> -Query $Query1 -Verbose -ErrorAction Stop
        }
        else{
            Invoke-SqlCmd @Params –ServerInstance $instance -Database "master" -QueryTimeout 7200 <#2 hours#> -Query "EXEC master.dbo.sp_GetIndexInfo" -Verbose -ErrorAction Stop
        }
        
        $dt = Get-Date -Format 'yyyy-MM-dd hh:mm:ss'; 
        Write-Warning "$dt Finished to run sp_GetIndexInfo"
	}

    # If result file already exists, remove it
    if (Test-Path "$PSScriptRoot\CheckResultIndex.xlsx") {
      Remove-Item "$PSScriptRoot\CheckResultIndex.xlsx" -Force
    }

    $files = get-childitem -path $IndexChecksFolderPath -filter "Check*.sql" | Sort-Object { [regex]::Replace($_.Name, '\d+', { $args[0].Value.PadLeft(20) }) }

    foreach ($filename in $files)
    {
        $dt = Get-Date -Format 'yyyy-MM-dd hh:mm:ss'
	    [string]$str = $dt + " Running [" + ($filename.Name) + "]"
        Write-Host $str -ForegroundColor Yellow

        try{
            $Result = Invoke-SqlCmd @Params –ServerInstance $instance -Database "master" -QueryTimeout 1800 -InputFile $filename.fullname -Verbose -ErrorAction Stop
        }
        catch 
        {
            Write-Warning "Error trying to run the script. $filename"
            $_.Exception.Message
            continue
        }

        $SecondsToRun = ((New-TimeSpan -Start $dt -End (Get-Date)).Seconds) + ((New-TimeSpan -Start $dt -End (Get-Date)).Minutes * 60)
		$dt = Get-Date -Format 'yyyy-MM-dd hh:mm:ss'
	    [string]$str = $dt + " Finished to run [" + ($filename.Name) + "], duration = " + $SecondsToRun.ToString()
        Write-Host $str -ForegroundColor Yellow

		$dt = Get-Date -Format 'yyyy-MM-dd hh:mm:ss'
	    [string]$str = $dt + " Starting to write results on spreadsheet"
        Write-Host $str -ForegroundColor Yellow

		if ($Result.count -eq 0){
			$Result = @([pscustomobject]@{Info="<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< ---------------------------------------------------------- no rows ---------------------------------------------------------- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>";})
		}

		$style = New-ExcelStyle -BackgroundColor LightYellow -Bold -Range "A1:D$NumberOfRowsDescription" -HorizontalAlignment Left -Merge `
								-VerticalAlignment Center -WrapText -BorderAround Thin

		$xl = $null
        $xl = $Result | Select-Object * -ExcludeProperty  "RowError", "RowState", "Table", "ItemArray", "HasErrors" | `
			Export-Excel -Path $FileOutput -WorkSheetname ($filename.Name).Replace('.sql', '') `
							-AutoSize -AutoFilter -KillExcel -ClearSheet -TableStyle Medium2 `
							-Title ($filename.Name).Replace('.sql', '') -TitleBold -TitleSize 20 -FreezePane 3 -PassThru

        $SheetName = ($filename.Name).Replace('.sql', '')
		$ws = $xl.Workbook.Worksheets[$SheetName]
        $ws.View.ZoomScale = 90

        $a = 65..90 | %{[char]$_}
		foreach ($c1 in $a) {
			#Set-ExcelRange -Address $ws.Column($c) -AutoFit
			$c2 = $c1 + '2' 
			$c2 = $c1 + ($NumberOfRowsDescription + 3).ToString()
			$ColValue = $ws.Cells["$c2"].Value
			if ($ColValue -like '*number of rows*'){
				$c2 = $c1 + ($NumberOfRowsDescription + 4).ToString()
				$c3 = $c1 + '1048576'
				$Range = $c2 + ':' + $c3 | Out-String
				Add-ConditionalFormatting -WorkSheet $ws -Address $Range -DataBarColor Blue
			}
			elseif ($ColValue -like '*modified rows*') {
				$c2 = $c1 + ($NumberOfRowsDescription + 4).ToString()
				$c3 = $c1 + '1048576'
				$Range = $c2 + ':' + $c3 | Out-String
				Add-ConditionalFormatting -WorkSheet $ws -Address $Range -DataBarColor Red
			}
			elseif ($ColValue -like '*latch since*') {
				$c2 = $c1 + ($NumberOfRowsDescription + 4).ToString()
				$c3 = $c1 + '1048576'
				$Range = $c2 + ':' + $c3 | Out-String
				Add-ConditionalFormatting -WorkSheet $ws -Address $Range -DataBarColor Red
			}
			elseif ($ColValue -like '*percent of*') {
				$c2 = $c1 + ($NumberOfRowsDescription + 4).ToString()
				$c3 = $c1 + '1048576'
				$Range = $c2 + ':' + $c3 | Out-String
				Add-ConditionalFormatting -WorkSheet $ws -Address $Range -DataBarColor Green
			}
			elseif ($ColValue -like '*comment*') {
				$c2 = $c1 + ($NumberOfRowsDescription + 4).ToString()
				$c3 = $c1 + '1048576'
				$Range = $c2 + ':' + $c3 | Out-String
				Add-ConditionalFormatting -WorkSheet $ws -Range $Range -RuleType NotEqual `
											-ConditionValue 'OK' -ForeGroundColor "Red"
			}
			elseif ($ColValue -eq $null) {
				break
			}
		}
        Close-ExcelPackage $xl #-Show
        $SecondsToRun = ((New-TimeSpan -Start $dt -End (Get-Date)).Seconds) + ((New-TimeSpan -Start $dt -End (Get-Date)).Minutes * 60)
		$dt = Get-Date -Format 'yyyy-MM-dd hh:mm:ss'
	    [string]$str = $dt + " Finished to write results on spreadsheet, duration = " + $SecondsToRun.ToString()
        Write-Host $str -ForegroundColor Yellow
    }
}
catch 
{
    Write-Warning "Error trying to run the script."
    $_.Exception.Message
    exit
}