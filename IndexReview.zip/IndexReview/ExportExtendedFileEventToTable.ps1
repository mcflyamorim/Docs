Clear-Host

function Transpose-Data{
    param(
        [String[]]$Names,
        [Object[][]]$Data
    )
    for($i = 0;; ++$i){
        $Props = [ordered]@{}
        for($j = 0; $j -lt $Data.Length; ++$j){
            if($i -lt $Data[$j].Length){
                $Props.Add($Names[$j], $Data[$j][$i])
            }
        }
        if(!$Props.get_Count()){
            break
        }
        [PSCustomObject]$Props
    }
}

# Installing SqlServer module...
try {
    if (-not (Get-Module SqlServer -Erroraction Stop)) {
		
        Write-Warning "SqlServer is not installed, trying to install it from Galery"
        $VerbosePreference = "SilentlyContinue"
        Install-Module SqlServer -AllowClobber
        Write-Warning "SqlServer installed successfully"
	}
} catch {
    Write-Warning "Error trying to install SqlServer. Aborting."
	exit
}


$sqlInstance = "dellfabiano\sql2019"
$xEventPath = 'D:\Fabiano\Trabalho\FabricioLima\Clientes\GrupoSoma\Statistics usage analysis\ExtendedEvents auto_stats\DBA_CaptureStatsInfo*.xel'
$Tab = "IF OBJECT_ID('tempdb.dbo.AutoStatsXEvent') IS NOT NULL DROP TABLE tempdb.dbo.AutoStatsXEvent;"
Invoke-Sqlcmd -ServerInstance $sqlInstance -Database "tempdb" -Query $Tab

foreach ($file in Get-ChildItem $xEventPath) {
    $dt = Get-Date -Format 'yyyy-MM-dd hh:mm:ss'; 
    Write-Warning "[$dt] Starting to read file $file"

    if ($DataXel -ne $null){
        $DataXel.Clear()
    }
    $DataXel = Read-SqlXEvent -FileName $file
    $DataXelCount = $DataXel.Count

    $dt = Get-Date -Format 'yyyy-MM-dd hh:mm:ss'; 
    Write-Warning "[$dt] Finished to read $DataXelCount rows on file $file"
    Write-Warning "[$dt] Starting to parse and bulk insert rows on SQL table"

    if ($XelTable -ne $null){
        $XelTable.Clear()
    }
    $XelTable = New-Object System.Data.DataTable
    $First = $true
    $i = 0
    $ProgressPercent = 0.00
    foreach ($row in $DataXel) {
        $i += 1
        $arrayrow = $XelTable.NewRow()
    
        foreach ($row1 in $row.PsObject.get_properties()) {
            if ($row1.Name -eq 'Fields'){
                $Fields = $row1.Value
                foreach ($field in $Fields) {
                    try {
                        if ($First) {
                            $Col = New-Object Data.DataColumn
                            $Col.ColumnName = $field.Key.ToString()
                            $XelTable.Columns.Add($Col)
                        }
                        if ($field.Value -eq $null) {
                            $arrayrow[$field.Key] = ""
                        }
                        else{
                            $arrayrow[$field.Key] = $field.Value
                        }
                    }
                    catch {
                        $_.Exception.Message
                        exit
                    }  
                }     
            }
            elseif ($row1.Name -eq 'Actions'){
                $array1 = $row1.Value | Select-Object -ExpandProperty Keys
                $array2 = $row1.Value | Select-Object -ExpandProperty Values
                $Actions = Transpose-Data Keys, Values $array1, $array2
                foreach ($ActionRow in $Actions) {
                    try {
                            if ($First) {
                                $Col = New-Object Data.DataColumn
                                $Col.ColumnName = $ActionRow.Keys
                                $XelTable.Columns.Add($Col)
                            }
                            if ($ActionRow.Values -eq $null) {
                                $arrayrow[$ActionRow.Keys] = ""
                            }
                            else {
                                $arrayrow[$ActionRow.Keys] = $ActionRow.Values
                            }
                            
                        }
                    catch {
                        $_.Exception.Message
                        exit
                    }  
                }
            }
            else {
                if ($First) {
                    $Col = New-Object Data.DataColumn
                    $Col.ColumnName = $row1.Name.ToString()
                    $Col.DataType = $row1.TypeNameOfValue
                    $XelTable.Columns.Add($Col)
                }
                if ($row1.value -eq $null) {
                    $arrayrow.Item($row1.Name) = ""
                }
                else {
                    $arrayrow.Item($row1.Name) = $row1.value
                }
            }
        }
        
        $XelTable.rows.Add($arrayrow)
        $First = $false
    
        #Print progress every 10k rows
        if ($i % 10000 -eq 0){
            $ProgressPercent = (($i / $DataXelCount) * 100).ToString("#.##")
            $dt = Get-Date -Format 'yyyy-MM-dd hh:mm:ss';
            
            Write-Warning "[$dt] $ProgressPercent% - Parsing file - Progress $i of $DataXelCount"
        }
    
        if (($i % 1000000 -eq 0) -or ($DataXelCount -eq $i)) {
            Write-SqlTableData -InputData $XelTable -SchemaName "dbo" -ServerInstance $sqlInstance -DatabaseName "tempdb" -TableName "AutoStatsXEvent" -Force
            $XelTable.Rows.Clear()
        }
    }    
}
